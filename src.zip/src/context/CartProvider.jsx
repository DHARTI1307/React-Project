// context/CartProvider.jsx
import { useState } from "react";
import { CartContext } from "./CartContext";

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState([]);
  const [wishlist, setWishlist] = useState([]);
  const [compare, setCompare] = useState([]); 

  // Add to cart
  const addToCart = (product) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find((item) => item.id === product.id);
      if (existingItem) {
        return prevCart.map((item) =>
          item.id === product.id
            ? { ...item, qty: item.qty +  (product.qty || 1) }
            : item
        );
      }
      return [...prevCart, { ...product, qty: product.qty || 1 }];
    });
  };

  // Add to wishlist
  const addToWishlist = (product) => {
    setWishlist((prev) =>
      prev.find((item) => item.id === product.id)
        ? prev
        : [...prev, { ...product, qty: product.qty || 1 }]
    );
  };

  // Remove from wishlist
  const removeFromWishlist = (productId) => {
    setWishlist((prev) => prev.filter((item) => item.id !== productId));
  };

  // Add to compare
  const addToCompare = (product) => {
    setCompare((prev) => {
      // limit compare list to 4 items (optional)
      if (prev.find((item) => item.id === product.id)) return prev;
      return prev.length >= 4 ? [...prev.slice(1), product] : [...prev, product];
    });
  };

  // Remove from compare
  const removeFromCompare = (id) => {
    setCompare((prev) => prev.filter((item) => item.id !== id));
  };

  // Remove from cart
  const removeFromCart = (id) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
  };

  // Clear cart
  const clearCart = () => setCart([]);

  // Total calculation
  const total = cart.reduce((acc, item) => acc + item.price * item.qty, 0);

  return (
    <CartContext.Provider
      value={{
        cart,
        wishlist,
        compare,
        addToCart,
        removeFromCart,
        addToWishlist,
        removeFromWishlist, 
        addToCompare,
        removeFromCompare,
        clearCart,
        total,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};
