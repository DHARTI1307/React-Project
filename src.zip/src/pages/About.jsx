import { useRef } from "react";
import Slider from "react-slick";
import Banner from "../components/Banner";
import {
  FaStar,
  FaChevronLeft,
  FaChevronRight,
  FaUser,
  FaComment,
  FaArrowRight,
  FaEnvelope,
} from "react-icons/fa";

const feedbacks = [
  {
    name: "Ridoy Rock",
    location: "London, UK",
    rating: 5.0,
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ",
    image: "https://i.pravatar.cc/100?img=1",
  },
  {
    name: "Ridoy Rock",
    location: "London, UK",
    rating: 4.0,
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ",
    image: "https://i.pravatar.cc/100?img=4",
  },
  {
    name: "Ridoy Rock",
    location: "London, UK",
    rating: 3.0,
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ",
    image: "https://i.pravatar.cc/100?img=3",
  },
  {
    name: "Ridoy Rock",
    location: "London, UK",
    rating: 4.0,
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ",
    image: "https://i.pravatar.cc/100?img=4",
  },
];

export default function AboutPage() {
  const sliderRef = useRef(null);

  const settings = {
    dots: false,
    infinite: true,
    speed: 600,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: false,
    arrows: false,
    responsive: [
      {
        breakpoint: 1024,
        settings: { slidesToShow: 2 },
      },
      {
        breakpoint: 768,
        settings: { slidesToShow: 1 },
      },
    ],
  };
  return (
    <>
      <div className="page-title-wrapper bg-[#FFFAEF] w-full h-[173px] py-10">
        <div className="flex justify-center">
          <h1 className="text-3xl font-semibold text-qblack">About Us</h1>
        </div>
        <div className="breadcrumb-wrapper font-400 text-[13px] mt-2 text-center text-qblack mb-[23px]">
          <span>
            <a href="/">
              <span className="mx-1 capitalize">home</span>
            </a>
            <span className="sperator">/</span>
          </span>
          <span>
            <a href="/">
              <span className="mx-1 capitalize">About</span>
            </a>
          </span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="aboutus-wrapper">
          <div className="w-full min-h-[665px] lg:flex lg:space-x-12 items-center pb-10 lg:pb-0">
            <div className="md:w-[570px] w-full md:h-[560px] h-auto rounded overflow-hidden my-5 lg:my-0" data-aos="fade-right">
              <img src="/Images/banner2.png" alt="about" className="w-full h" />
            </div>
            <div className="content flex-1" data-aos="fade-left">
              <h1 className="text-[18px] font-medium text-qblack mb-2.5">
                What is e-commerce business?
              </h1>
              <p className="text-[15px] text-qgraytwo leading-7 mb-2.5">
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make a type specimen book. It has
                survived not only five centuries but also the on leap into
                electronic typesetting.
              </p>
              <ul className="text-[15px] text-qgraytwo leading-7 list-disc ml-5 mb-5">
                <li>slim body with metal cover</li>
                <li>
                  latest Intel Core i5-1135G7 processor (4 cores / 8 threads)
                </li>
                <li>8GB DDR4 RAM and fast 512GB PCIe SSD</li>
                <li>
                  NVIDIA GeForce MX350 2GB GDDR5 graphics card backlit keyboard
                </li>
              </ul>
              <a href="/contact">
                <div className="w-[130px] h-10">
                  <span className="inline-block bg-pink-300 hover:bg-pink-400 text-gray-900 font-semibold px-6 py-2.5 rounded transition-colors duration-300">
                    Contact Us
                  </span>
                </div>
              </a>
            </div>
          </div>
        </div>
        <div className="customer-feedback w-full bg-white py-[60px] mb-10" data-aos="fade-up">
          <div className="title flex justify-center mb-5">
            <h1 className="text-[30px] font-semibold text-qblack">
              Customers Feedback
            </h1>
          </div>
          <div className="feedback-slider-wrapper w-vw relative overflow-hidden">
            <Slider ref={sliderRef} {...settings}>
              {feedbacks.map((item, index) => (
                <div key={index} className="px-4">
                  <div className="bg-gray-50 rounded-2xl shadow-md p-6 h-full flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-1 text-yellow-400 mb-8">
                        {[...Array(5)].map((_, i) => (
                          <FaStar key={i} />
                        ))}
                        <span className="text-gray-600 text-sm ml-1">
                          ({item.rating.toFixed(1)})
                        </span>
                      </div>
                      <p className="text-gray-600 text-md text-justify leading-relaxed mb-10">
                        {item.text}
                      </p>
                    </div>
                    <div className="flex items-center gap-3 mt-auto">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div className="text-left">
                        <p className="font-semibold text-gray-800">
                          {item.name}
                        </p>
                        <p className="text-sm text-gray-500">{item.location}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </Slider>

            {/* Custom Navigation */}
            <div className="flex justify-center gap-4 mt-10">
              <button
                onClick={() => sliderRef.current.slickPrev()}
                className="group w-12 h-12 flex items-center justify-center border-2 border-pink-400 rounded-full hover:bg-pink-400 hover:text-white transition"
              >
                <FaChevronLeft className="text-pink-400 group-hover:text-white transition" />
              </button>
              <button
                onClick={() => sliderRef.current.slickNext()}
                className="group w-12 h-12 flex items-center justify-center border-2 border-pink-400 rounded-full hover:bg-pink-400 hover:text-white transition"
              >
                <FaChevronRight className="text-pink-400 group-hover:text-white transition" />
              </button>
            </div>
          </div>
        </div>

        <Banner showBanner={false} showClients={false} showFlashSale={false} showDiscountSale={false}/>

        <div className="blog-post-wrapper w-full mb-[30px] mt-20" data-aos="fade-up">
          <div className="blog-post-title flex justify-center items-cente mb-[30px]">
            <h1 className="text-3xl font-semibold text-qblack">My Latest News</h1>
          </div>
          <div className="blogs-wrapper w-full">
            <div className="grid md:grid-cols-2 grid-cols-1 lg:gap-[30px] gap-5">
              <div data-aos="fade-up" className="item w-full aos-init aos-animate">
                <div className="blog-card-wrapper w-full border border-[#D3D3D3] ">
                  <div className="img w-full h-[340px]">
                    <img
                      src="/Images/blog-img.jpg"
                      alt="blog"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-[24px]">
                    <div className="short-data flex space-x-9 items-center mb-3">
                      <div className="flex space-x-1.5 items-center">
                        <span>
                          <FaUser />
                        </span>
                        <span className="text-base text-qgraytwo capitalize">
                          By admin
                        </span>
                      </div>
                      <div className="flex space-x-1.5 items-center">
                        <span>
                          <FaComment />
                        </span>
                        <span className="text-base text-qgraytwo">6 Comments</span>
                      </div>
                    </div>
                    <div className="details">
                      <a href="/blogs/blog">
                        <h1 className="text-[22px] text-qblack hover:text-blue-500 font-semibold line-clamp-2 mb-1 capitalize">
                          reprehenderit non esse anim laboris reprehenderit
                          officia
                        </h1>
                      </a>
                      <p className="text-qgraytwo text-[15px] leading-[30px] line-clamp-2 mb-3">
                        irure laborum qui deserunt excepteur id ad sit quis
                        laboris duis ut cillum eiusmod non sint exercitation
                        nulla tempor nostrud eiusmod commodo mollit magna sint
                        laboris excepteur elit cupidatat id
                      </p>
                      <a href="#">
                        <div className="flex items-center space-x-2">
                          <span className="text-qblack text-base font-semibold">
                            View More
                          </span>
                          <span>
                            <FaArrowRight />
                          </span>
                        </div>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div data-aos="fade-up" className="item w-full aos-init aos-animate">
                <div className="blog-card-wrapper w-full border border-[#D3D3D3]">
                  <div className="img w-full h-[340px]">
                    <img
                      src="/Images/blog-img.jpg"
                      alt="blog"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-[24px]">
                    <div className="short-data flex space-x-9 items-center mb-3">
                      <div className="flex space-x-1.5 items-center">
                        <span>
                          <FaUser />
                        </span>
                        <span className="text-base text-qgraytwo capitalize">
                          By admin
                        </span>
                      </div>
                      <div className="flex space-x-1.5 items-center">
                        <span>
                          <FaComment />
                        </span>
                        <span className="text-base text-qgraytwo">8 Comments</span>
                      </div>
                    </div>
                    <div className="details">
                      <a href="/blogs/blog">
                        <h1 className="text-[22px] text-qblack hover:text-blue-500 font-semibold line-clamp-2 mb-1 capitalize">
                          aliquip duis nostrud ex cillum laborum adipisicing
                          occaecat
                        </h1>
                      </a>
                      <p className="text-qgraytwo text-[15px] leading-[30px] line-clamp-2 mb-3">
                        adipisicing dolor esse voluptate occaecat laborum fugiat
                        adipisicing laboris id cupidatat deserunt exercitation
                        et velit consectetur eiusmod pariatur ullamco enim ut
                        nulla qui minim sunt minim amet non culpa aliqua
                      </p>
                      <a href="#">
                        <div className="flex items-center space-x-2">
                          <span className="text-qblack text-base font-semibold">
                            View More
                          </span>
                          <span>
                            <FaArrowRight />
                          </span>
                        </div>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Banner showBanner={false} showServices={false} showFlashSale={false} showClients={false}/>
    </>
  );
}
