// src/pages/ProductDetail.jsx
import { useParams } from "react-router-dom";
import { useCart } from "../hooks/useCart";
import { useState } from "react";
import { products } from "../data/Products";
import ProductCard from "../components/ProductCard";
import { FaStar, FaFacebook, FaPinterest, FaTwitter, FaRegHeart, FaBalanceScale } from "react-icons/fa";
import { FaLinkedin } from "react-icons/fa6";
import toast from "react-hot-toast";

export default function ProductDetail() {
  const [activeTab, setActiveTab] = useState("description");
  const { id } = useParams();
  const { addToCart, addToWishlist, addToCompare  } = useCart();
  const [qty, setQty] = useState(1);

  const product = products.find((p) => p.id === parseInt(id));

  if (!product) {
    return <div className="text-center py-20">Product not found 😢</div>;
  }

  const handleAddToCart = () => {
    addToCart({ ...product, qty });
     toast.success("🛒 Item added to cart successfully!" , { position: "top-right" });
  };

  const handleWishlist = (e) => {
    addToWishlist(product);
    toast.success("Item added to wishlist successfully!" , { position: "top-right" });
  };

  const handleCompare = (e) => {
    addToCompare(product);
    toast.success("Item added to compare successfully!" , { position: "top-right" });
  };

  return (
    <>
      <div className="max-w-7xl mx-auto px-4 py-10">
        <div className="grid md:grid-cols-2 gap-10 pb-[60px]">
          <div>
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-[500px] object-contain rounded shadow"
            />
          </div>
          <div>
            <h1 className="text-3xl font-bold mb-4">{product.name}</h1>
            <div
              data-aos="fade-up"
              className="flex space-x-[10px] items-center mb-6 aos-init aos-animate"
            >
              <div className="flex text-yellow-400">
                <FaStar />
                <FaStar />
                <FaStar />
                <FaStar />
                <FaStar />
              </div>
              <span className="text-[13px] font-normal text-qblack">
                6 Reviews
              </span>
            </div>
            <p className="flex space-x-2 items-center mb-7">
              <span className="text-sm font-500 text-qgray line-through mt-2">
                {" "}
                ₹{product.oldprice}
              </span>
              <span className="text-xl text-pink-500 font-semibold text-qred">
                {" "}
                ₹{product.price}
              </span>
            </p>
            <p className="text-gray-600 mb-6">{product.description}</p>
            <div className="colors mb-[30px]">
              <span className="text-sm font-normal uppercase text-qgray mb-[14px] inline-block">
                COLOR
              </span>
              <div className="flex space-x-4 items-center">
                <div>
                  <button
                    type="button"
                    className="w-[20px] h-[20px]  rounded-full focus:ring-2  ring-offset-2 flex justify-center items-center"
                  >
                    <span
                      className="w-[20px] h-[20px] block rounded-full"
                      style={{ background: "rgb(255, 188, 99)" }}
                    ></span>
                  </button>
                </div>
                <div>
                  <button
                    type="button"
                    className="w-[20px] h-[20px]  rounded-full focus:ring-2  ring-offset-2 flex justify-center items-center"
                  >
                    <span
                      className="w-[20px] h-[20px] block rounded-full"
                      style={{ background: "rgb(100, 158, 255)" }}
                    ></span>
                  </button>
                </div>
                <div>
                  <button
                    type="button"
                    className="w-[20px] h-[20px]  rounded-full focus:ring-2  ring-offset-2 flex justify-center items-center"
                  >
                    <span
                      className="w-[20px] h-[20px] block rounded-full"
                      style={{ background: "rgb(255, 113, 115)" }}
                    ></span>
                  </button>
                </div>
                <div>
                  <button
                    type="button"
                    className="w-[20px] h-[20px]  rounded-full focus:ring-2  ring-offset-2 flex justify-center items-center"
                  >
                    <span
                      className="w-[20px] h-[20px] block rounded-full"
                      style={{ background: "rgb(73 163 62)" }}
                    ></span>
                  </button>
                </div>
                <div></div>
              </div>
            </div>
            <div className="flex items-center gap-6 mb-4">
              <div className="flex items-center p-2 gap-2 border border-qgray-border">
                <button
                  onClick={() => setQty((prev) => (prev > 1 ? prev - 1 : 1))}
                  className="px-3 py-1 rounded"
                >
                  -
                </button>
                <span>{qty}</span>
                <button
                  onClick={() => setQty((prev) => prev + 1)}
                  className="px-3 py-1 rounded"
                >
                  +
                </button>
              </div>
              <button onClick={handleCompare}>
                <span
                  className="w-12 h-12 flex justify-center items-center bg-primarygray border border-qgray-border"
                >
                  <FaBalanceScale className="w-5 h-5" />
                </span>
              </button>
              <button onClick={handleWishlist}>
                <span className="w-12 h-12 flex justify-center items-center bg-primarygray border border-qgray-border">
                  <FaRegHeart className="w-5 h-5" />
                </span>
              </button>
              <button
                onClick={handleAddToCart}
                className="px-10 py-3 bg-black text-white rounded hover:bg-pink-600 transition"
              >
                Add to Cart
              </button>
            </div>

            <div className="my-[20px]">
              <p className="text-[15px] text-qgray leading-7">
                <span className="text-qblack">Category :</span>{" "}
                {product.category}
              </p>
              <p className="text-[15px] text-qgray leading-7">
                <span className="text-qblack">Tags :</span> {product.tags}
              </p>
              <p className="text-[15px] text-qgray leading-7">
                <span className="text-qblack">SKU:</span> {product.sku}
              </p>
            </div>

            <div className="flex gap-10 items-center">
              <FaFacebook />
              <FaPinterest />
              <FaTwitter />
              <FaLinkedin />
            </div>
          </div>
        </div>
      </div>
      <div className="bg-gray">
        <div className="max-w-7xl mx-auto px-4 py-10">
          <div className="product-des-wrapper w-full relative pb-[60px]">
            <div className="tab-buttons w-full mb-10 mt-5 sm:mt-0">
              <ul className="flex space-x-12 ">
                {["description", "reviews", "seller"].map((tab) => (
                  <li key={tab}>
                    <button
                      onClick={() => setActiveTab(tab)}
                      className={`py-[15px] sm:text-[15px] text-sm font-medium cursor-pointer transition-colors duration-300 ${
                        activeTab === tab
                          ? "border-b-2 border-qypink text-qblack"
                          : "border-b-2 border-transparent text-qgray hover:text-qblack"
                      }`}
                    >
                      {tab === "description"
                        ? "Description"
                        : tab === "reviews"
                        ? "Reviews"
                        : "Seller Info"}
                    </button>
                  </li>
                ))}
              </ul>
              <div className="w-full h-[2px] bg-[#E8E8E8] absolute left-0 sm:top-[50px] top-[36px] -z-10"></div>
            </div>
            <div className="tab-contents w-full min-h-[200px] ">
              {activeTab === "description" && (
                <div className="w-full tab-content-item">
                  <h6 className="text-[18px] font-medium text-qblack mb-2">
                    Introduction
                  </h6>
                  <p className="text-[15px] text-qgray text-normal mb-10">
                    {product.description}
                  </p>
                </div>
              )}

              {activeTab === "reviews" && (
                <div className="tab-content-item">
                  <h6 className="text-[18px] font-medium text-qblack mb-2">
                    Customer Reviews
                  </h6>
                  <p className="text-[15px] text-qgray">
                    No reviews yet. Be the first to review this product!
                  </p>
                </div>
              )}

              {activeTab === "seller" && (
                <div className="tab-content-item">
                  <h6 className="text-[18px] font-medium text-qblack mb-2">
                    Seller Information
                  </h6>
                  <ul>
                    <li className="text-qgray leading-[30px]">
                      <span className="text-[15px] font-normal text-qblack">
                        Sold by{" "}
                      </span>
                      : TechWorld Pvt Ltd
                    </li>
                    <li className="text-qgray leading-[30px]">
                      <span className="text-[15px] font-normal text-qblack">
                        Location{" "}
                      </span>
                      : Ahmedabad, India
                    </li>
                    <li className="text-qgray leading-[30px]">
                      <span className="text-[15px] font-normal text-qblack">
                        Contact{" "}
                      </span>
                      : info@techworld.com
                    </li>
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 py-10">
        <div className="mb-12">
          <h3 className="text-2xl font-bold">Related Product </h3>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 py-4">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
