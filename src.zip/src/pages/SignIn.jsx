import AuthForm from "../components/AuthForm";

export default function SignIn() {
  return (
    <AuthForm
      title="Sign In"
      buttonText="Login"
      linkText="Don’t have an account?"
      linkTo="/signup"
    />
  );
}
