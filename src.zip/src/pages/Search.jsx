import React from "react";
import ProductCard from "../components/ProductCard";
import { useLocation, Link } from "react-router-dom";

export default function SearchPage() {
  const { state } = useLocation();
  const { results = [], term, category } = state || {};

  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-xl font-semibold mb-4">
        Search Results for "<span className="text-pink-500">{term}</span>"
        {category && category !== "All" && (
          <span> in {category} category</span>
        )}
      </h2>

      {results.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {results.map((product) => (
           <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <p className="text-gray-500">No products found.</p>
      )}
    </div>
  );
}
 