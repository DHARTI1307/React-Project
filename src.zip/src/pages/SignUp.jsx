import AuthForm from "../components/AuthForm";

export default function SignUp() {
  return (
    <AuthForm
      title="Sign Up"
      buttonText="Register"
      linkText="Already have an account?"
      linkTo="/signin"
    />
  );
}
