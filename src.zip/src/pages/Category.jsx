import { useParams, Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { products } from "../data/products"; // your product data
import { categories } from "../data/categories"; // your category data
import ProductCard from "../components/ProductCard";

export default function CategoryPage() {
  const { categorySlug } = useParams();
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [currentCategory, setCurrentCategory] = useState(null);

  useEffect(() => {
    if (categorySlug === "all") {
      // ✅ All categories selected
      setCurrentCategory({ name: "All Categories" });
      setFilteredProducts(products);
    } else {
      const cat = categories.find((c) => c.slug === categorySlug);
      setCurrentCategory(cat);
      if (cat) {
        const filtered = products.filter((p) => p.category === cat.slug);
        setFilteredProducts(filtered);
      } else {
        setFilteredProducts([]);
      }
    }
  }, [categorySlug]);

  return (
    <div className="container mx-auto px-4 py-8">
      {/* ✅ Breadcrumb */}
      <div className="text-sm mb-4">
        <Link to="/" className="text-gray-500 hover:text-gray-800">
          Home
        </Link>{" "}
        ›{" "}
        <span className="text-pink-600">
          {currentCategory?.name || "All Categories"}
        </span>
      </div>

      {/* ✅ If All Categories, show category list at top */}
      {categorySlug === "all" && (
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-4 mb-8">
          {categories.map((cat) => (
            <Link
              key={cat.slug}
              to={`/category/${cat.slug}`}
              className="flex flex-col items-center text-center hover:scale-105 transition-transform"
            >
              <img
                src={cat.image || "/no-image.png"}
                alt={cat.name}
                className="w-30 h-30 object-cover rounded-full mb-2 border"
              />
              <span className="text-gray-700 font-medium">{cat.name}</span>
            </Link>
          ))}
        </div>
      )}

      {/* ✅ Product Grid */}
      <div className="grid xl:grid-cols-4 sm:grid-cols-2 grid-cols-1 xl:gap-[30px] gap-5 mb-[40px]">
        {filteredProducts.length > 0 ? (
          filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))
        ) : (
          <p className="text-gray-600 text-center col-span-3">
            No products found.
          </p>
        )}
      </div>
    </div>
  );
}
