import { useState } from "react";
import { useCart } from "../hooks/useCart";
import { useNavigate } from "react-router-dom";

export default function Checkout() {
  const { cart, total, clearCart } = useCart();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    fname: "",
    lname: "",
    email: "",
    phone: "",
    address: "",
  });
  const [paymentMethod, setPaymentMethod] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleNext = () => setStep((prev) => prev + 1);
  const handlePrev = () => setStep((prev) => prev - 1);

  return (
    <>
      <div className="page-title-wrapper bg-[#FFFAEF] w-full h-[173px] py-10">
        <div className="flex justify-center">
          <h1 className="text-3xl font-semibold text-qblack">Checkout</h1>
        </div>
        <div className="breadcrumb-wrapper font-400 text-[13px] mt-2 text-center text-qblack mb-[23px]">
          <span>
            <a href="/">
              <span className="mx-1 capitalize">home</span>
            </a>
            <span className="sperator">/</span>
          </span>
          <span>
            <a href="/checkout">
              <span className="mx-1 capitalize">checkout</span>
            </a>
          </span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12">
        {step === 1 && (
          <div className="w-full lg:flex lg:space-x-[30px]">
            <div className="lg:w-1/2 w-full">
              <h1 className="sm:text-2xl text-xl text-qblack font-medium mb-5">
                Shipping Details
              </h1>
              <div className="form-area">
                <form className="grid md:grid-cols-2 gap-4">
                  <input
                    type="text"
                    name="fname"
                    placeholder="First Name"
                    value={form.fname}
                    onChange={handleChange}
                    className="border border-qgray-border p-2 rounded w-full"
                  />
                  <input
                    type="text"
                    name="lname"
                    placeholder="Last Name"
                    value={form.lname}
                    onChange={handleChange}
                    className="border border-qgray-border p-2 rounded w-full"
                  />
                  <input
                    type="email"
                    name="email"
                    placeholder="Email"
                    value={form.email}
                    onChange={handleChange}
                    className="border border-qgray-border p-2 rounded w-full"
                  />
                  <input
                    type="phone"
                    name="phone"
                    placeholder="Phone"
                    value={form.phone}
                    onChange={handleChange}
                    className="border border-qgray-border p-2 rounded w-full"
                  />
                  <input
                    type="text"
                    name="city"
                    placeholder="City"
                    value={form.city}
                    onChange={handleChange}
                    className="border border-qgray-border p-2 rounded w-full"
                  />
                  <input
                    type="text"
                    name="zipcode"
                    placeholder="ZipCode"
                    value={form.zipcode}
                    onChange={handleChange}
                    className="border border-qgray-border p-2 rounded w-full"
                  />
                  <input
                    type="text"
                    name="country"
                    placeholder="Country"
                    value={form.country}
                    onChange={handleChange}
                    className="border border-qgray-border p-2 rounded w-full md:col-span-2"
                  />
                  <textarea
                    name="address"
                    placeholder="Address"
                    value={form.address}
                    onChange={handleChange}
                    className="border border-qgray-border p-2 rounded w-full md:col-span-2"
                  />
                  <div className="md:col-span-2 flex justify-center"></div>
                </form>
              </div>
            </div>
            <div className="flex-1">
              <h1 className="sm:text-2xl text-xl text-qblack font-medium mb-5">
                Order Summary
              </h1>
              <div className="w-full px-10 py-[20px] border border-[#EDEDED]">
                <div className="sub-total mb-3">
                  <div className=" flex justify-between mb-5">
                    <p className="text-[13px] font-medium text-qblack uppercase">
                      PROduct
                    </p>
                    <p className="text-[13px] font-medium text-qblack uppercase">
                      total
                    </p>
                  </div>
                  <div className="w-full h-[1px] bg-[#EDEDED]"></div>
                </div>
                <div className="product-list w-full mb-[20px]">
                  <ul className="flex flex-col space-y-5">
                    {cart.map((item) => (
                      <li key={item.id}>
                        <div className="flex justify-between items-center">
                          <div>
                            <h4 className="text-[15px] text-qblack mb-2.5">
                              {item.name}
                              <sup className="text-[13px] text-qgray ml-2 mt-2">
                                × {item.qty}
                              </sup>
                            </h4>
                          </div>
                          <div>
                            <span className="text-[15px] text-qblack font-medium">
                              ₹{item.price * item.qty}
                            </span>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="w-full h-[1px] bg-[#EDEDED]"></div>
                <div className="mt-[10px]">
                  <div className=" flex justify-between mb-5">
                    <p className="text-[13px] font-medium text-qblack uppercase">
                      SUBTOTAL
                    </p>
                    <p className="text-[15px] font-medium text-qblack uppercase">
                      ₹{total}{" "}
                    </p>
                  </div>
                </div>
                <div className="w-full mt-[10px]">
                  <div className="sub-total mb-6">
                    <div className=" flex justify-between mb-5">
                      <div>
                        <span className="text-xs text-qgraytwo mb-3 block">
                          SHIPPING
                        </span>
                        <p className="text-base font-medium text-qblack">
                          Free Shipping
                        </p>
                      </div>
                      <p className="text-[15px] font-medium text-qblack">+₹0</p>
                    </div>
                    <div className="w-full h-[1px] bg-[#EDEDED]"></div>
                  </div>
                </div>
                <div className="mt-[10px]">
                  <div className=" flex justify-between mb-5">
                    <p className="text-2xl font-medium text-qblack">Total</p>
                    <p className="text-2xl font-medium text-qred"> ₹{total}</p>
                  </div>
                </div>
                <div className="shipping mt-[10px]"></div>
                <button
                  type="button"
                  onClick={handleNext}
                  className="w-full h-[50px] black-btn flex justify-center items-center"
                >
                  <span className="text-md font-semibold">Place Order Now</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="w-full lg:flex lg:space-x-[30px]">
            <div className="lg:w-1/2 w-full">
              <h1 className="sm:text-2xl text-xl text-qblack font-medium mb-5">
                Payment Method
              </h1>
              <div className="space-y-2 mb-10">
                <label className="flex items-center space-x-2">
                  <input
                    type="radio"
                    name="payment"
                    value="card"
                    checked={paymentMethod === "card"}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                  />
                  <span>Credit / Debit Card</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input
                    type="radio"
                    name="payment"
                    value="cod"
                    checked={paymentMethod === "cod"}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                  />
                  <span>Cash on Delivery</span>
                </label>
              </div>
              <div className="mb-20 flex gap-2 lg:justify-between">
                <button
                  className="px-4 py-2 h-[50px] black-btn flex justify-center items-center"
                  onClick={handlePrev}
                >
                  Back to Shipping
                </button>
                <button
                  className="px-4 py-2 h-[50px] black-btn flex justify-center items-center"
                  onClick={handleNext}
                >
                  Continue to Payment
                </button>
              </div>
            </div>
            <div className="flex-1">
              <h1 className="sm:text-2xl text-xl text-qblack font-medium mb-5">
                Order Summary
              </h1>
              <div className="w-full px-10 py-[20px] border border-[#EDEDED]">
                <div className="sub-total mb-3">
                  <div className=" flex justify-between mb-5">
                    <p className="text-[13px] font-medium text-qblack uppercase">
                      PROduct
                    </p>
                    <p className="text-[13px] font-medium text-qblack uppercase">
                      total
                    </p>
                  </div>
                  <div className="w-full h-[1px] bg-[#EDEDED]"></div>
                </div>
                <div className="product-list w-full mb-[20px]">
                  <ul className="flex flex-col space-y-5">
                    {cart.map((item) => (
                      <li key={item.id}>
                        <div className="flex justify-between items-center">
                          <div>
                            <h4 className="text-[15px] text-qblack mb-2.5">
                              {item.name}
                              <sup className="text-[13px] text-qgray ml-2 mt-2">
                                × {item.qty}
                              </sup>
                            </h4>
                          </div>
                          <div>
                            <span className="text-[15px] text-qblack font-medium">
                              ₹{item.price * item.qty}
                            </span>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="w-full h-[1px] bg-[#EDEDED]"></div>
                <div className="mt-[10px]">
                  <div className=" flex justify-between mb-5">
                    <p className="text-[13px] font-medium text-qblack uppercase">
                      SUBTOTAL
                    </p>
                    <p className="text-[15px] font-medium text-qblack uppercase">
                      ₹{total}{" "}
                    </p>
                  </div>
                </div>
                <div className="w-full mt-[10px]">
                  <div className="sub-total mb-6">
                    <div className=" flex justify-between mb-5">
                      <div>
                        <span className="text-xs text-qgraytwo mb-3 block">
                          SHIPPING
                        </span>
                        <p className="text-base font-medium text-qblack">
                          Free Shipping
                        </p>
                      </div>
                      <p className="text-[15px] font-medium text-qblack">+₹0</p>
                    </div>
                    <div className="w-full h-[1px] bg-[#EDEDED]"></div>
                  </div>
                </div>
                <div className="mt-[10px]">
                  <div className=" flex justify-between mb-5">
                    <p className="text-2xl font-medium text-qblack">Total</p>
                    <p className="text-2xl font-medium text-qred"> ₹{total}</p>
                  </div>
                </div>
                <div className="shipping mt-[10px]"></div>
              </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="w-full lg:flex lg:space-x-[30px]">
            <div className="lg:w-1/2 w-full">
              <h1 className="sm:text-2xl text-xl text-qblack font-medium mb-5">
                Confirm Order
              </h1>
              <div className="space-y-2">
                <table className="border border-qgray-border p-2 text-center w-full">
                  <thead>
                    <tr className="bg-gray-100 border-b border-qgray-border">
                      <th className="p-4 font-bold">Product</th>
                      <th className="p-4 font-bold">Price</th>
                      <th className="p-4 font-bold">Qty</th>
                      <th className="p-4 font-bold">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {cart.map((item) => (
                      <tr key={item.id} className="bg-gray-100 border-b border-qgray-border">
                        <td className="p-4">{item.name}</td>
                        <td className="p-4">{item.price}</td>
                        <td className="p-4">{item.qty}</td>
                        <td className="p-4">₹{item.price * item.qty}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="my-4 flex justify-between">
                <button
                  className="px-4 py-2 black-btn flex justify-center items-center"
                  onClick={handlePrev}
                >
                  Back to Payment
                </button>
                <button
                  className="px-4 py-2 black-btn flex justify-center items-center"
                  onClick={handleNext}
                >
                  Confirm Order
                </button>
              </div>
            </div>
            <div className="flex-1">
              <h1 className="sm:text-2xl text-xl text-qblack font-medium mb-5">
                Order Summary
              </h1>
              <div className="w-full px-10 py-[20px] border border-[#EDEDED]">
                <div className="mt-[10px]">
                  <div className=" flex justify-between mb-5">
                    <p className="text-[13px] font-medium text-qblack uppercase">
                      SUBTOTAL
                    </p>
                    <p className="text-[15px] font-medium text-qblack uppercase">
                      ₹{total}{" "}
                    </p>
                  </div>
                </div>
                <div className="w-full mt-[10px]">
                  <div className="sub-total mb-6">
                    <div className=" flex justify-between mb-5">
                      <div>
                        <span className="text-xs text-qgraytwo mb-3 block">
                          SHIPPING
                        </span>
                        <p className="text-base font-medium text-qblack">
                          Free Shipping
                        </p>
                      </div>
                      <p className="text-[15px] font-medium text-qblack">+₹0</p>
                    </div>
                    <div className="w-full h-[1px] bg-[#EDEDED]"></div>
                  </div>
                </div>
                <div className="mt-[10px]">
                  <div className=" flex justify-between mb-5">
                    <p className="text-2xl font-medium text-qblack">Total</p>
                    <p className="text-2xl font-medium text-qred"> ₹{total}</p>
                  </div>
                </div>
                <div className="shipping mt-[10px]"></div>
              </div>
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="text-center py-10">
            <h2 className="text-2xl font-bold mb-4">Order Complete!</h2>
            <p className="mb-4">
              Thank you for your purchase. Your order has been placed
              successfully.
            </p>
            <button
              className="px-6 py-2 black-btn"
             onClick={() => { clearCart();  navigate("/"); }}>
              Back to Home
            </button>
          </div>
        )}
      </div>
    </>
  );
}
