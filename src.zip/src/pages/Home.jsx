import { products } from "../data/products";
import ProductCard from "../components/ProductCard";
import Banner from "../components/Banner";

export default function Home() {
  const trendyProducts = products.filter(p => p.isTrendy).slice(0, 4);
  const newArrivalProducts = products.filter(p => p.isNewArrival).slice(0, 4);
  return (
    <>
    <div className="max-w-7xl mx-auto px-4 py-12">
      <Banner showClients={false} showFlashSale={false} showDiscountSale={false} />
      <section className="mb-12" data-aos="fade-down">
        <h3 className="text-2xl font-bold">Trendy Design</h3>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 py-4">
          {trendyProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
        </div>
      </section>
      <Banner showBanner={false} showServices={false} showClients={false} showDiscountSale={false}/>
      <section className="mb-12" data-aos="fade-up">
        <h3 className="text-2xl font-bold">New Arrival</h3>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 py-4">
          {newArrivalProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
        </div>
      </section>      
    </div>
    <Banner showBanner={false} showServices={false} showFlashSale={false}/>
    </>
  );
}
