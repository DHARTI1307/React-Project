import { useCart } from "../hooks/useCart";
import { useNavigate } from "react-router-dom";

export default function Cart() {
  const { cart, total, removeFromCart, clearCart } = useCart();
  const navigate = useNavigate();

  const handleCheckout = () => {
    if (cart.length === 0) {
      alert("Your cart is empty!");
      return;
    }
    navigate("/checkout");
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 mb-10">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl">Your Cart</h1>
      </div>

      {cart.length === 0 ? (
        <p>Your cart is empty 🛒</p>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            <div className="md:col-span-8">
              <div className="overflow-x-auto">
                <table className="border border-qgray-border p-2 text-center w-full">
                  <thead>
                    <tr className="bg-gray-100 border-b border-qgray-border">
                      <th className="p-4 font-bold">Product Name</th>
                      <th className="p-4 font-bold">Price</th>
                      <th className="p-4 font-bold">Quantity</th>
                      <th className="p-4 font-bold">Total</th>
                      <th className="p-4"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {cart.map((item) => (
                      <tr
                        key={item.id}
                        className="border-b border-qgray-border"
                      >
                        <td className="p-4">{item.name}</td>
                        <td className="p-4">₹{item.price}</td>
                        <td className="p-4">{item.qty}</td>
                        <td className="p-4">₹{item.price * item.qty}</td>
                        <td className="p-4">
                          <button
                            className="bg-red-500 text-white px-2 py-1 rounded"
                            onClick={() => removeFromCart(item.id)}
                          >
                            Remove
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="flex justify-between gap-2 mb-5">
                <a
                  href="/"
                  className="bg-gray-700 text-white mt-2 px-4 py-2 rounded"
                >
                  Continue Shopping
                </a>
                <button
                  className="bg-gray-700 text-white mt-2 px-4 py-2 rounded"
                  onClick={clearCart}
                >
                  Clear Cart
                </button>
              </div>
            </div>

            <div className="md:col-span-4 border border-qgray-border p-4">
              <h3 className="text-lg font-bold">CART TOTALS</h3>
              <div className="flex justify-between items-center mt-4 font-semibold text-md">
                <div>Sub-Total:</div>
                <div className="text-end">₹{total}</div>
              </div>
              <div className="flex justify-between items-center mt-4 font-semibold text-md">
                <div>Total:</div>
                <div className="text-end">₹{total}</div>
              </div>
              <div className="flex justify-center">
                <button
                  className="bg-gray-700 text-white mt-2 px-4 py-2 rounded"
                  onClick={handleCheckout}
                >
                  Proceed to Checkout
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
