import Banner from "../components/Banner";
import { FaUser, FaComment, FaArrowRight } from "react-icons/fa";

export default function BlogPage() {
  return (
    <>
      <div className="page-title-wrapper bg-[#FFFAEF] w-full h-[173px] py-10">
        <div className="flex justify-center">
          <h1 className="text-3xl font-semibold text-qblack">Our Blogs</h1>
        </div>
        <div className="breadcrumb-wrapper font-400 text-[13px] mt-2 text-center text-qblack mb-[23px]">
          <span>
            <a href="/">
              <span className="mx-1 capitalize">Home</span>
            </a>
            <span className="sperator">/</span>
          </span>
          <span>
            <a href="/">
              <span className="mx-1 capitalize">Blogs</span>
            </a>
          </span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12">
        <div
          className="blog-post-wrapper w-full mb-[30px] mt-20"
          data-aos="fade-up"
        >
          <div className="blogs-wrapper w-full">
            <div className="grid md:grid-cols-2 grid-cols-1 lg:gap-[30px] gap-5">
              <div
                data-aos="fade-up"
                className="item w-full aos-init aos-animate"
              >
                <div className="blog-card-wrapper w-full border border-[#D3D3D3] ">
                  <div className="img w-full h-[340px]">
                    <img
                      src="/Images/blog-img.jpg"
                      alt="blog"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-[24px]">
                    <div className="short-data flex space-x-9 items-center mb-3">
                      <div className="flex space-x-1.5 items-center">
                        <span>
                          <FaUser />
                        </span>
                        <span className="text-base text-qgraytwo capitalize">
                          By admin
                        </span>
                      </div>
                      <div className="flex space-x-1.5 items-center">
                        <span>
                          <FaComment />
                        </span>
                        <span className="text-base text-qgraytwo">
                          6 Comments
                        </span>
                      </div>
                    </div>
                    <div className="details">
                      <a href="/blogs/blog">
                        <h1 className="text-[22px] text-qblack hover:text-blue-500 font-semibold line-clamp-2 mb-1 capitalize">
                          reprehenderit non esse anim laboris reprehenderit
                          officia
                        </h1>
                      </a>
                      <p className="text-qgraytwo text-[15px] leading-[30px] line-clamp-2 mb-3">
                        irure laborum qui deserunt excepteur id ad sit quis
                        laboris duis ut cillum eiusmod non sint exercitation
                        nulla tempor nostrud eiusmod commodo mollit magna sint
                        laboris excepteur elit cupidatat id
                      </p>
                      <a href="#">
                        <div className="flex items-center space-x-2">
                          <span className="text-qblack text-base font-semibold">
                            View More
                          </span>
                          <span>
                            <FaArrowRight />
                          </span>
                        </div>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div
                data-aos="fade-up"
                className="item w-full aos-init aos-animate"
              >
                <div className="blog-card-wrapper w-full border border-[#D3D3D3]">
                  <div className="img w-full h-[340px]">
                    <img
                      src="/Images/blog-img.jpg"
                      alt="blog"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-[24px]">
                    <div className="short-data flex space-x-9 items-center mb-3">
                      <div className="flex space-x-1.5 items-center">
                        <span>
                          <FaUser />
                        </span>
                        <span className="text-base text-qgraytwo capitalize">
                          By admin
                        </span>
                      </div>
                      <div className="flex space-x-1.5 items-center">
                        <span>
                          <FaComment />
                        </span>
                        <span className="text-base text-qgraytwo">
                          8 Comments
                        </span>
                      </div>
                    </div>
                    <div className="details">
                      <a href="/blogs/blog">
                        <h1 className="text-[22px] text-qblack hover:text-blue-500 font-semibold line-clamp-2 mb-1 capitalize">
                          aliquip duis nostrud ex cillum laborum adipisicing
                          occaecat
                        </h1>
                      </a>
                      <p className="text-qgraytwo text-[15px] leading-[30px] line-clamp-2 mb-3">
                        adipisicing dolor esse voluptate occaecat laborum fugiat
                        adipisicing laboris id cupidatat deserunt exercitation
                        et velit consectetur eiusmod pariatur ullamco enim ut
                        nulla qui minim sunt minim amet non culpa aliqua
                      </p>
                      <a href="#">
                        <div className="flex items-center space-x-2">
                          <span className="text-qblack text-base font-semibold">
                            View More
                          </span>
                          <span>
                            <FaArrowRight />
                          </span>
                        </div>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Banner showBanner={false} showServices={false} showFlashSale={false} showClients={false}/>
    </>
  );
}
