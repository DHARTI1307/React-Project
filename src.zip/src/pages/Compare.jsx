import { useCart } from "../hooks/useCart";

export default function ComparePage() {
  const { compare, removeFromCompare } = useCart();

  const PageHeader = () => (
    <div className="page-title-wrapper bg-[#FFFAEF] w-full h-[173px] py-10">
      <div className="flex justify-center">
        <h1 className="text-3xl font-semibold text-qblack">
          {" "}
          Product Comparison
        </h1>
      </div>
      <div className="breadcrumb-wrapper font-400 text-[13px] mt-2 text-center text-qblack mb-[23px]">
        <span>
          <a href="/">
            <span className="mx-1 capitalize">home</span>
          </a>
          <span className="sperator">/</span>
        </span>
        <span>
          <a href="/">
            <span className="mx-1 capitalize">Comparison</span>
          </a>
        </span>
      </div>
    </div>
  );

  if (compare.length === 0)
    return (
      <>
        <PageHeader />
        <p className="p-4 text-center">No products to compare.</p>;
      </>
    );

  return (
    <>
      <PageHeader />
      <div className="max-w-7xl mx-auto px-4 py-10 overflow-x-auto">
        <table className="min-w-full border-collapse border border-gray-300 text-center">
          <tbody>
            {/* delete button row */}
            <tr className="bg-gray-100">
              <td className="border border-gray-300 p-3 w-48 text-left"></td>
              {compare.map((item) => (
                <td key={item.id} className="border border-gray-300 p-3">
                  <button
                    onClick={() => removeFromCompare(item.id)}
                    className="bg-red-500 hover:bg-red-600 text-white text-xs px-3 py-1 rounded mb-2"
                  >
                    Remove
                  </button>
                </td>
              ))}
            </tr>
            {/* image and product name */}
            <tr className="bg-gray-100">
              <td className="border border-gray-300 p-3 w-48 text-left font-semibold">
                Features
              </td>
              {compare.map((item) => (
                <td key={item.id} className="border border-gray-300 p-3">
                  <div className="flex flex-col items-center">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-24 h-24 object-contain mb-2"
                    />
                    <p className="font-medium">{item.name}</p>
                  </div>
                </td>
              ))}
            </tr>
            {/* price */}
            <tr className="bg-gray-100">
              <td className="border border-gray-300 p-3 w-48 text-left font-semibold">
                Price
              </td>
              {compare.map((item) => (
                <td key={item.id} className="border border-gray-300 p-3">
                  ₹{item.price}
                </td>
              ))}
            </tr>
            {/* brand */}
            <tr>
              <td className="border border-gray-300 p-3 text-left font-semibold">
                Category
              </td>
              {compare.map((item) => (
                <td key={item.id} className="border border-gray-300 p-3">
                  {item.category || "—"}
                </td>
              ))}
            </tr>
            {/* availability */}
            <tr>
              <td className="border border-gray-300 p-3 text-left font-semibold">
                Availability
              </td>
              {compare.map((item) => (
                <td key={item.id} className="border border-gray-300 p-3">
                  {item.stock > 0 ? (
                    <span className="text-green-600 font-medium">In Stock</span>
                  ) : (
                    <span className="text-red-600 font-medium">
                      Out of Stock
                    </span>
                  )}
                </td>
              ))}
            </tr>
            {/* description */}
            <tr>
              <td className="border border-gray-300 p-3 text-left font-semibold">
                Description
              </td>
              {compare.map((item) => (
                <td
                  key={item.id}
                  className="border border-gray-300 p-3 text-gray-600"
                >
                  {item.description || "—"}
                </td>
              ))}
            </tr>
            {/* <tr>
            <td className="border border-gray-300 p-3 text-left font-semibold">
              Rating
            </td>
            {compare.map((item) => (
              <td key={item.id} className="border border-gray-300 p-3">
                ⭐ {item.rating || "4.5"}
              </td>
            ))}
          </tr> */}
          </tbody>
        </table>
      </div>
    </>
  );
}

// <div className="max-w-7xl mx-auto px-4 py-10">
//       <h2 className="text-2xl font-bold mb-6 text-center">Product Comparison</h2>

//       <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
//         {compare.map((item) => (
//           <div
//             key={item.id}
//             className="border p-4 rounded-lg shadow hover:shadow-lg transition"
//           >
//             <img
//               src={item.image}
//               alt={item.name}
//               className="w-full h-48 object-contain mb-4"
//             />
//             <h3 className="text-lg font-semibold mb-2">{item.name}</h3>
//             <p className="text-gray-600 mb-2">₹{item.price}</p>
//             <button
//               onClick={() => removeFromCompare(item.id)}
//               className="bg-red-500 hover:bg-red-600 text-white px-4 py-1 rounded"
//             >
//               Remove
//             </button>
//           </div>
//         ))}
//       </div>
//     </div>
