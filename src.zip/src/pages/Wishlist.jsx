import { useCart } from "../hooks/useCart";
import { useNavigate } from "react-router-dom";

export default function WishlistPage() {
  const { wishlist, removeFromWishlist, addToCart } = useCart();
  const navigate = useNavigate();

  const PageHeader = () => (
    <div className="page-title-wrapper bg-[#FFFAEF] w-full h-[173px] py-10">
      <div className="flex justify-center">
        <h1 className="text-3xl font-semibold text-qblack"> Wishlist</h1>
      </div>
      <div className="breadcrumb-wrapper font-400 text-[13px] mt-2 text-center text-qblack mb-[23px]">
        <span>
          <a href="/">
            <span className="mx-1 capitalize">home</span>
          </a>
          <span className="sperator">/</span>
        </span>
        <span>
          <a href="/">
            <span className="mx-1 capitalize">Wishlist</span>
          </a>
        </span>
      </div>
    </div>
  );

  if (wishlist.length === 0)
    return (
      <>
        <PageHeader />
        <h3 className="p-5 text-center text-xl">Your wishlist is empty.</h3>
      </>
    );

  return (
    <>
      <PageHeader />
      <div className="max-w-7xl mx-auto px-4 py-10 mb-[100px]">
        <h2 className="text-2xl font-bold mb-4"></h2>
        <div className="overflow-x-auto">
          <table className="border border-qgray-border p-2 text-center w-full">
            <thead>
              <tr className="sfont-medium bg-gray-100 border-b border-qgray-border uppercase">
                <th className="p-4 pl-10 block whitespace-nowrap  w-[380px]">
                  Product
                </th>
                <th className="p-4 whitespace-nowrap text-center">Price </th>
                <th className="p-4 whitespace-nowrap text-center">Total</th>
                <th className="p-4 whitespace-nowrap text-center">
                  Addtocart
                </th>
                <th className="p-4 whitespace-nowrap text-center">Remove</th>
              </tr>
            </thead>
            <tbody>
              {wishlist.map((item) => (
                <tr key={item.id}>
                  <td className="pl-10 p-4">
                    <div className="flex space-x-6 items-center">
                      <div className="w-[80px] h-[80px] overflow-hidden flex justify-center items-center border border-[#EDEDED]">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-40 h-40 object-cover mb-3"
                        />
                      </div>
                      <h3 className="font-semibold">{item.name}</h3>
                    </div>
                  </td>
                  <td className="text-center p-4"> ₹{item.price} </td>
                  <td className="text-center p-4">
                    ₹{item.price * item.qty}
                  </td>
                  <td className="text-center p-4">
                    <button
                    onClick={() => {
      addToCart(item);
      removeFromWishlist(item.id); 
      setTimeout(() => navigate("/cart"), 200);
    }}
                      className="inline-block bg-pink-300 hover:bg-pink-400 text-gray-900 font-semibold px-2 py-1 rounded transition-colors duration-300"
                    >
                      Add to Cart
                    </button>
                  </td>
                  <td className="text-center p-4">
                    <button 
                      onClick={() => removeFromWishlist(item.id)}
                      className="bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded"
                    >
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

//  <div className="p-4">
//       <h2 className="text-2xl font-bold mb-4">Wishlist</h2>
//       <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
//         {wishlist.map((item) => (
//           <div
//             key={item.id}
//             className="border rounded-lg p-4 flex flex-col items-center text-center bg-white"
//           >
//             <img
//               src={item.image}
//               alt={item.name}
//               className="w-40 h-40 object-cover mb-3"
//             />
//             <h3 className="font-semibold">{item.name}</h3>
//             <p className="text-gray-600 mb-3">₹{item.price}</p>
//             <div className="flex gap-2">
//               <button
//                 onClick={() => {
//                   addToCart(item);
//                   removeFromWishlist(item.id);
//                   navigate("/cart");
//                 }}
//                 className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded"
//               >
//                 Go to Cart
//               </button>
//               <button
//                 onClick={() => removeFromWishlist(item.id)}
//                 className="bg-red-500 hover:bg-red-600 text-white px-4 py-1 rounded"
//               >
//                 Remove
//               </button>
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
