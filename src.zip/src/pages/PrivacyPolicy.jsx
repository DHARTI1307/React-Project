export default function PrivacyPolicyPage() {
  return (
    <>
      <div className="page-title-wrapper bg-[#FFFAEF] w-full h-[173px] py-10">
        <div className="flex justify-center">
          <h1 className="text-3xl font-semibold text-qblack">
            Privacy Policy
          </h1>
        </div>
        <div className="breadcrumb-wrapper font-400 text-[13px] mt-2 text-center text-qblack mb-[23px]">
          <span>
            <a href="/">
              <span className="mx-1 capitalize">home</span>
            </a>
            <span className="sperator">/</span>
          </span>
          <span>
            <a href="/">
              <span className="mx-1 capitalize">Privacy Policy</span>
            </a>
          </span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-10 mb-[100px]">
        <div className="content-item w-full mb-10">
          <h2 className="text-[18px] font-medium text-qblack mb-5">
            1. What Are Terms and Conditions?
          </h2>
          <p className="text-[15px] text-qgraytwo leading-7">
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been the industry's standard dummy text
            ever since the 1500s, when an unknown printer took a galley of type
            and scrambled it to make a type specimen book. It has survived not
            only five centuries but also the on leap into electronic
            typesetting, remaining essentially unchanged. It wasn’t popularised
            in the 1960s with the release of Letraset sheets containing Lorem
            Ipsum passages, andei more recently with desktop publishing software
            like Aldus PageMaker including versions of Lorem Ipsum to make a
            type specimen book.
          </p>
        </div>
      </div>
    </>
  );
}
