import React, { useEffect, useState } from "react";
import Banner from "../components/Banner";
import { products } from "../data/products";
import ProductSidebar from "../components/ProductSidebar";
import ProductCard from "../components/ProductCard";

export default function ProductPage() {
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  const [filters, setFilters] = useState({
    categories: [],
    brands: [],
    sizes: [],
    tags: [],
    priceRange: [500, 5000],
  });

  const [filteredProducts, setFilteredProducts] = useState(products);

  // 🧮 Filter logic
  useEffect(() => {
    let result = products.filter((p) => {
      const matchCategory =
        filters.categories.length === 0 ||
        filters.categories.includes(p.category?.toLowerCase());
      const matchBrand =
        filters.brands.length === 0 ||
        filters.brands.includes(p.brand?.toLowerCase());
      const matchSize =
        filters.sizes.length === 0 ||
        filters.sizes.includes(p.size?.toLowerCase());
      const matchTag =
        filters.tags.length === 0 ||
        filters.tags.some((tag) =>
          p.tags?.map((t) => t.toLowerCase()).includes(tag.toLowerCase())
        );
      const matchPrice =
        p.price >= filters.priceRange[0] && p.price <= filters.priceRange[1];

      return matchCategory && matchBrand && matchSize && matchTag && matchPrice;
    });

    setFilteredProducts(result);
  }, [filters]);

  return (
    <>
      {/* Page Title */}
      <div className="page-title-wrapper bg-[#FFFAEF] w-full h-[173px] py-10">
        <div className="flex justify-center">
          <h1 className="text-3xl font-semibold text-qblack">
            Product List
          </h1>
        </div>
        <div className="breadcrumb-wrapper font-400 text-[13px] mt-2 text-center text-qblack mb-[23px]">
          <span>
            <a href="/">
              <span className="mx-1 capitalize">home</span>
            </a>
            <span className="sperator">/</span>
          </span>
          <span>
            <a href="/">
              <span className="mx-1 capitalize">Product List</span>{" "}
            </a>
          </span>
        </div>
      </div>

      {/* Main Section */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="w-full lg:flex lg:space-x-[30px]">
          {/* Sidebar */}
          <div className="lg:w-[270px]">
            {/* Desktop Sidebar */}
            <div className="filter-widget w-full fixed lg:relative left-0 top-0 h-screen z-10 lg:h-auto overflow-y-scroll lg:overflow-y-auto bg-white px-[30px] pt-[40px] mb-[30px]  hidden lg:block">
              <ProductSidebar filters={filters} setFilters={setFilters} />
            </div>

            {/* Mobile Sidebar */}
            {isMobileSidebarOpen && (
              <div className="fixed inset-0 z-50 bg-white w-3/4 h-full shadow-lg overflow-y-scroll p-6 lg:hidden">
                <button
                  className="absolute top-4 right-4 text-xl font-bold"
                  onClick={() => setIsMobileSidebarOpen(false)}
                >
                  ✖
                </button>
                <ProductSidebar filters={filters} setFilters={setFilters} />
              </div>
            )}

            <div className="w-full hidden lg:block h-[295px]"></div>
          </div>

          {/* Products */}
          <div className="flex-1">
            <div className="products-sorting w-full bg-white md:h-[70px] flex md:flex-row flex-col md:space-y-0 space-y-5 md:justify-between md:items-center p-[30px] mb-[40px]">
              <p className="font-400 text-[13px]">
                <span className="text-qgray"> Showing</span> 1–16 of 66 results
              </p>
              <button
                type="button"
                onClick={() => setIsMobileSidebarOpen(true)}
                className="w-10 lg:hidden h-10 rounded flex justify-center items-center border border-qyellow text-qyellow"
              >
                ☰
              </button>
            </div>

            {/* Product Grid */}
            <div className="grid xl:grid-cols-3 sm:grid-cols-2 grid-cols-1 xl:gap-[30px] gap-5 mb-[40px]">
              {filteredProducts.length > 0 ? (
                filteredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))
              ) : (
                <p className="text-gray-600 text-center col-span-3">
                  No products found.
                </p>
              )}
            </div>
          </div>
        </div>
      </div>

      <Banner
        showBanner={false}
        showServices={false}
        showFlashSale={false}
        showClients={false}
      />
    </>
  );
}

{
  /* <div className="grid xl:grid-cols-3 sm:grid-cols-2 grid-cols-1  xl:gap-[30px] gap-5 mb-[40px]">
              {filteredProducts.length > 0 ? (
                filteredProducts.map((product) => (
                  <div className="item group" data-aos="fade-up">
                    <div className="w-full h-[380spx] bg-white shadow hover:shadow-lg relative p-3.5 mb-6 transition flex flex-col content-center overflow-hidden">
                      <Link to={`/product/${product.id}`}>
                        <img
                          src={product.image}
                          alt={product.name}
                          className="cursor-pointer product-card-img w-full h-[330px]"
                        />
                      </Link>
                      <div className="product-card-details px-[20px] pt-[20px] pb-[10px] relative">
                        <Link to={`/product/${product.id}`}>
                          <h2 className="text-xl leading-6 font-medium text-qblack mb-2 hover:text-pink-500 transition">
                            {product.name}
                          </h2>
                        </Link>
                        <div className="flex items-center gap-1 text-yellow-400 mb-2">
                          {[...Array(5)].map((_, i) => (
                            <FaStar key={i} />
                          ))}
                        </div>
                        <p className="price">
                          <span className="main-price text-gray-600 line-through font-600 text-[18px]">
                            {" "}
                            ₹{product.oldprice}
                          </span>
                          <span className="offer-price text-red-600 font-600 text-[18px] ml-2">
                            {" "}
                            ₹{product.price}
                          </span>
                        </p>
                      </div>

                      <div className="quick-access-btns flex flex-col space-y-2 absolute group-hover:right-4 -right-10 top-20  transition-all duration-300 ease-in-out">
                        <button onClick={handleCompare}>
                          <span className="w-10 h-10 flex justify-center items-center bg-primarygray rounded">
                            <FaBalanceScale className="w-5 h-5" />
                          </span>
                        </button>
                        <button onClick={handleWishlist}>
                          <span className="w-10 h-10 flex justify-center items-center bg-primarygray rounded">
                            <FaRegHeart className="w-5 h-5" />
                          </span>
                        </button>
                      </div>
                      <div className="absolute w-full h-10 px-[30px]  left-0 -bottom-10 group-hover:bottom-3 transition-all duration-300 ease-in-out">
                        <button
                          onClick={handleAddToCart}
                          className="black-btn w-full h-full flex justify-center items-center"
                        >
                          Add to Cart
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-gray-600 text-center col-span-3">
                  No products found.
                </p>
              )}
            </div> */
}
// <div
//   key={product.id}
//   className="border rounded-lg p-4 flex flex-col items-center text-center bg-white"
// data-aos="fade-up">
//   <img
//     src={product.image}
//     alt={product.name}
//     className="w-40 h-40 object-cover mb-3"
//   />
//   <h3 className="font-semibold">{product.name}</h3>
//   <p className="text-gray-600 mb-3">₹{product.price}</p>
//   <div className="flex items-center gap-2 mb-3">
//     <button
//       onClick={() => decreaseQty(product.id)}
//       className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1 rounded"
//     >
//       -
//     </button>
//     <span>{quantities[product.id] || 1}</span>
//     <button
//       onClick={() => increaseQty(product.id)}
//       className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1 rounded"
//     >
//       +
//     </button>
//   </div>
//   <div className="flex gap-2">
//     <button
//       onClick={() => handleAddToCart(product)}
//       className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded"
//     >
//       Add to Cart
//     </button>
//     <button
//       onClick={() => addToWishlist(product)}
//       className="bg-pink-500 hover:bg-pink-600 text-white px-4 py-1 rounded"
//     >
//       Add to Wishlist
//     </button>
//   </div>
// </div>

// <div className="filter-subject-item pb-10 border-b border-qgray-border">
//   <div className="subject-title mb-[30px]">
//     <h1 className="text-black text-base font-500">
//       Product categories
//     </h1>
//   </div>
//   <div className="filter-items"></div>
// </div>
// <div className="filter-subject-item pb-10 border-b border-qgray-border mt-10">
//   <div className="subject-title mb-[30px]">
//     <h1 className="text-black text-base font-500">Price Range</h1>
//   </div>
//   <div className="price-range mb-5"></div>
//   <p className="text-xs text-qblack font-400">Price: $200 - $500</p>
// </div>
// <div className="filter-subject-item pb-10 border-b border-qgray-border mt-10">
//   <div className="subject-title mb-[30px]">
//     <h1 className="text-black text-base font-500">Brands</h1>
//   </div>
//   <div className="filter-items"></div>
// </div>
// <div className="filter-subject-item pb-10 border-b border-qgray-border mt-10">
//   <div className="subject-title mb-[30px]">
//     <h1 className="text-black text-base font-500">Storage</h1>
//   </div>
//   <div className="filter-items">
//     <div className="flex space-x-[5px] flex-wrap">
//       <span className=" font-400 border border-qgray-border text-xs px-[14px] py-[6px] cursor-pointer mb-[5px]  text-qgray ">
//         64GB
//       </span>
//       <span className=" font-400 border border-qgray-border text-xs px-[14px] py-[6px] cursor-pointer mb-[5px]  text-qgray ">
//         128GB
//       </span>
//       <span className=" font-400 border border-qgray-border text-xs px-[14px] py-[6px] cursor-pointer mb-[5px]  text-qgray ">
//         256GB
//       </span>
//       <span className=" font-400 border border-qgray-border text-xs px-[14px] py-[6px] cursor-pointer mb-[5px]  text-qgray ">
//         512GB
//       </span>
//       <span className=" font-400 border border-qgray-border text-xs px-[14px] py-[6px] cursor-pointer mb-[5px]  text-qgray ">
//         1024GB
//       </span>
//     </div>
//   </div>
// </div>
// <div className="filter-subject-item pb-10 mt-10">
//   <div className="subject-title mb-[30px]">
//     <h1 className="text-black text-base font-500">Sizes</h1>
//   </div>
//   <div className="filter-items"></div>
// </div>
// <button
//   type="button"
//   className="w-10 h-10 fixed top-5 right-5 z-50 rounded  lg:hidden flex justify-center items-center border border-qred text-qred"
// >
//   <svg
//     xmlns="http://www.w3.org/2000/svg"
//     className="h-5 w-5"
//     viewBox="0 0 20 20"
//     fill="currentColor"
//   >
//     <path
//       fill-rule="evenodd"
//       d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
//       clip-rule="evenodd"
//     ></path>
//   </svg>
// </button>
