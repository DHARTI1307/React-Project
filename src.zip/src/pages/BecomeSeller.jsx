import {
  FaStore,
  FaTshirt,
  FaPhoneAlt,
  FaEnvelope,
  FaMapMarkerAlt,
} from "react-icons/fa";

export default function BecomeSellerPage() {
  return (
    <>
      <div className="page-title-wrapper bg-[#FFFAEF] w-full h-[173px] py-10">
        <div className="flex justify-center">
          <h1 className="text-3xl font-semibold text-qblack">
            {" "}
            Become a Seller
          </h1>
        </div>
        <div className="breadcrumb-wrapper font-400 text-[13px] mt-2 text-center text-qblack mb-[23px]">
          <span>
            <a href="/">
              <span className="mx-1 capitalize">home</span>
            </a>
            <span className="sperator">/</span>
          </span>
          <span>
            <a href="/">
              <span className="mx-1 capitalize">Become a Seller</span>
            </a>
          </span>
        </div>
      </div>
      <div className="text-center mb-10 px-4">
        <p className="text-gray-600 max-w-2xl mx-auto mt-10">
          Join our platform and showcase your clothing brand to thousands of
          fashion lovers. Grow your business effortlessly with our e-commerce
          ecosystem.
        </p>
      </div>

      {/* Form Section */}
      <div className="max-w-4xl mx-auto bg-white p-8 shadow-md rounded-2xl">
        <form className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-gray-700 font-medium mb-1">
              Store Name
            </label>
            <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2">
              <FaStore className="text-gray-400 mr-2" />
              <input
                type="text"
                name="storeName"
                value=""
                onChange=""
                placeholder="Your Store Name"
                className="w-full outline-none"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-gray-700 font-medium mb-1">
              Owner Name
            </label>
            <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2">
              <FaTshirt className="text-gray-400 mr-2" />
              <input
                type="text"
                name="ownerName"
                value=""
                onChange=""
                placeholder="Full Name"
                className="w-full outline-none"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-gray-700 font-medium mb-1">
              Email
            </label>
            <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2">
              <FaEnvelope className="text-gray-400 mr-2" />
              <input
                type="email"
                name="email"
                value=""
                onChange=""
                placeholder="you@example.com"
                className="w-full outline-none"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-gray-700 font-medium mb-1">
              Phone
            </label>
            <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2">
              <FaPhoneAlt className="text-gray-400 mr-2" />
              <input
                type="text"
                name="phone"
                value=""
                onChange=""
                placeholder="+91 9876543210"
                className="w-full outline-none"
                required
              />
            </div>
          </div>
          <div className="md:col-span-2">
            <label className="block text-gray-700 font-medium mb-1">
              Address
            </label>
            <div className="flex items-start border border-gray-300 rounded-lg px-3 py-2">
              <FaMapMarkerAlt className="text-gray-400 mt-1 mr-2" />
              <textarea
                name="address"
                value=""
                onChange=""
                placeholder="Store Address"
                className="w-full outline-none"
                rows="2"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-gray-700 font-medium mb-1">
              Category
            </label>
            <select
              name="category"
              value=""
              onChange=""
              className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none"
              required
            >
              <option value="">Select Category</option>
              <option value="mens">Men’s Clothing</option>
              <option value="womens">Women’s Clothing</option>
              <option value="kids">Kids’ Clothing</option>
              <option value="accessories">Accessories</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-700 font-medium mb-1">
              Description
            </label>
            <textarea
              name="description"
              value=""
              onChange=""
              placeholder="Tell us about your brand..."
              className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none"
              rows="3"
              required
            />
          </div>

          <div className="md:col-span-2 text-center">
            <button
              type="submit"
              className="inline-block bg-pink-300 hover:bg-pink-400 text-gray-900 font-semibold px-6 py-2.5 rounded transition-colors duration-300"
            >
              Submit Application
            </button>
          </div>
        </form>
      </div>

      {/* Benefits Section */}
      <div className="max-w-6xl mx-auto mt-16 text-center px-4 mb-10">
        <h2 className="text-3xl font-bold text-gray-800 mb-6">
          Why Sell With Us?
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              icon: (
                <FaStore className="text-pink-400 w-10 h-10 mb-3 mx-auto" />
              ),
              title: "Reach More Customers",
              desc: "Get your products in front of thousands of shoppers across India.",
            },
            {
              icon: (
                <FaTshirt className="text-pink-400 w-10 h-10 mb-3 mx-auto" />
              ),
              title: "Zero Setup Cost",
              desc: "Start selling instantly without any upfront costs or hidden fees.",
            },
            {
              icon: (
                <FaPhoneAlt className="text-pink-400 w-10 h-10 mb-3 mx-auto" />
              ),
              title: "Easy Management",
              desc: "Manage orders, track inventory, and receive payments effortlessly.",
            },
          ].map((item, i) => (
            <div
              key={i}
              className="bg-white p-6 rounded-xl shadow hover:shadow-lg transition transform hover:-translate-y-1"
            >
              {item.icon}
              <h3 className="text-xl font-semibold text-gray-800 mb-2">
                {item.title}
              </h3>
              <p className="text-gray-600">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
