export default function ProductFilterSidebar({ filters, setFilters }) {
  const handleCheckbox = (value, key) => {
    const selected = filters[key];
    if (selected.includes(value)) {
      setFilters({ ...filters, [key]: selected.filter((i) => i !== value) });
    } else {
      setFilters({ ...filters, [key]: [...selected, value] });
    }
  };

  const handlePriceChange = (e) => {
    const value = parseInt(e.target.value);
    setFilters({ ...filters, priceRange: [500, value] });
  };

  return (
    <>
      {/* Product Categories */}
      <div className="filter-subject-item pb-5 border-b border-qgray-border">
        <h1 className="text-base font-semibold text-gray-900 mb-8">
          Product Categories
        </h1>
        <div className="space-y-3">
          {["womens", "mens", "kids"].map((cat) => (
            <label
              key={cat}
              className="flex items-center justify-between cursor-pointer group"
            >
              <div className="flex items-center">
                <input
                  type="checkbox"
                  className="w-4 h-4 border-2 border-gray-300 rounded"
                  checked={filters.categories.includes(cat)}
                  onChange={() => handleCheckbox(cat, "categories")}
                />
                <span className="ml-3 text-sm text-gray-700 capitalize">
                  {cat}
                </span>
              </div>
            </label>
          ))}
        </div>
      </div>

      {/* Price Range */}
      <div className="filter-subject-item pb-5 border-b border-qgray-border mt-5">
        <h3 className="text-base font-semibold text-gray-900 mb-4">
          Price Range
        </h3>
        <input
          type="range"
          min="500"
          max="5000"
          value={filters.priceRange[1]}
          onChange={handlePriceChange}
          className="w-full h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer"
        />
        <div className="mt-3 text-sm text-gray-600">
          Price: ₹{filters.priceRange[0]} - ₹{filters.priceRange[1]}
        </div>
      </div>

      {/* Brands */}
      <div className="filter-subject-item pb-5 border-b border-qgray-border mt-5">
        <h3 className="text-base font-semibold text-gray-900 mb-4">Brands</h3>
        <div className="space-y-3">
          {["uspolo", "levis", "nike"].map((b) => (
            <label key={b} className="flex items-center cursor-pointer">
              <input
                type="checkbox"
                className="w-4 h-4 border-2 border-gray-300 rounded"
                checked={filters.brands.includes(b)}
                onChange={() => handleCheckbox(b, "brands")}
              />
              <span className="ml-3 text-sm text-gray-700 capitalize">{b}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Sizes */}
      <div className="filter-subject-item pb-5 border-b border-qgray-border mt-5">
        <h3 className="text-base font-semibold text-gray-900 mb-4">Sizes</h3>
        <div className="space-y-3">
          {["s", "m", "l"].map((s) => (
            <label key={s} className="flex items-center cursor-pointer">
              <input
                type="checkbox"
                className="w-4 h-4 border-2 border-gray-300 rounded"
                checked={filters.sizes.includes(s)}
                onChange={() => handleCheckbox(s, "sizes")}
              />
              <span className="ml-3 text-sm text-gray-700 uppercase">{s}</span>
            </label>
          ))}
        </div>
      </div>
    </>
  );
}
