import React from "react";
import { FaTruck, FaUndoAlt, FaLock, FaStar,FaEnvelope } from "react-icons/fa";
import { Link } from "react-router-dom";

export default function Banner({
  showBanner = true,
  showServices = true,
  showClients = true,
  showFlashSale = true,
  showDiscountSale = true,
}) {
  // Banner items
  const bannerItems = [
    {
      id: 1,
      image: "/Images/banner1.png",
      bgColor: "bg-cyan-200",
      tag: "BOYS STYLE",
      title: "Best Styles for all Boys",
      link: "/category/mens",
      buttonText: "Shop Now",
    },
    {
      id: 2,
      image: "/Images/banner2.png",
      bgColor: "bg-blue-200",
      tag: "GIRLS FASHION",
      title: "Trendy Looks for Girls",
      link: "/category/womens",
      buttonText: "Shop Now",
    },
    {
      id: 3,
      image: "/Images/banner3.png",
      bgColor: "bg-amber-100",
      tag: "KIDS COLLECTION",
      title: "Playful Styles for Kids",
      link: "/category/kids",
      buttonText: "Shop Now",
    },
  ];

  // Services items
  const services = [
    {
      id: 1,
      icon: <FaTruck className="w-8 h-8 text-pink-400 stroke-[2]" />,
      title: "Free Shipping",
      subtitle: "When ordering over $100",
    },
    {
      id: 2,
      icon: <FaUndoAlt className="w-8 h-8 text-pink-400" />,
      title: "Free Return",
      subtitle: "Get Return within 30 days",
    },
    {
      id: 3,
      icon: <FaLock className="w-8 h-8 text-pink-400" />,
      title: "Secure Payment",
      subtitle: "100% Secure Online Payment",
    },
    {
      id: 4,
      icon: <FaStar className="w-8 h-8 text-pink-400" />,
      title: "Best Quality",
      subtitle: "Original Product Guaranteed",
    },
  ];

  // Clients logos
  const clients = [
    "/Images/client-1.png",
    "/Images/client-2.png",
    "/Images/client-3.png",
    "/Images/client-4.png",
    "/Images/client-5.png",
    "/Images/client-6.png",
    "/Images/client-6.png",
    "/Images/client-5.png",
    "/Images/client-4.png",
    "/Images/client-3.png",
    "/Images/client-2.png",
    "/Images/client-1.png",
  ];

  //Flash sale
  const flashSaleStyle = {
    backgroundImage: "url('/Images/banner4.jpg')",
    backgroundPosition: "0% 0%",
    backgroundSize: "cover",
    backgroundRepeat: "no-repeat",
  };

  //Discount sale
  const DiscountSaleStyle = {
    backgroundImage: "url('/Images/discount-banner.jpg')",
    backgroundPosition: "0% 0%",
    backgroundSize: "cover",
    backgroundRepeat: "no-repeat",
  };

  return (
    <>
      {/* Banner Section */}
      {showBanner && (
        <section className="mb-12" data-aos="fade-up">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {bannerItems.map((item) => (
              <div
                key={item.id}
                className={`${item.bgColor} overflow-hidden xl:h-[600px]`}
              >
                <div className="relative h-full flex flex-col">
                  {/* Image */}
                  <div className="flex-1 flex items-center justify-center overflow-hidden">
                   
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Content Overlay */}
                  <div className="absolute bottom-[32px] left-0 xl:w-[306px] sm:w-full w-[306px] bg-white py-6 px-[26px] bg-opacity-[0.92]">
                    {/* Tag */}
                    <div className="mb-3">
                      <span className="inline-block bg-gray-800 text-white text-xs font-semibold px-4 py-1.5 rounded-full uppercase tracking-wide">
                        {item.tag}
                      </span>
                    </div>

                    {/* Title */}
                    <h3 className="text-2xl font-bold text-gray-900 mb-4 leading-tight">
                      {item.title}
                    </h3>

                    {/* Button */}
                    <Link
                      to={item.link}
                      className="inline-block bg-pink-300 hover:bg-pink-400 text-gray-900 font-semibold px-6 py-2.5 rounded transition-colors duration-300"
                    >
                      {item.buttonText}
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Best Services Section */}
      {showServices && (
        <section
          className="best-services mb-12 flex flex-col px-10 space-y-10 lg:space-y-0 lg:flex-row lg:justify-between lg:items-center lg:h-[110px] lg:py-0 py-10 bg-cover bg-no-repeat"
          data-aos="fade-up"
          style={{ backgroundImage: "url('/Images/service-bg.png')" }}
        >
          {services.map((service) => (
            <div key={service.id} className="item">
              <div className="flex space-x-5 items-center">
                <div>{service.icon}</div>
                <div>
                  <p className="text-white text-[15px] font-semibold tracking-wide mb-1">
                    {service.title}
                  </p>
                  <p className="text-sm text-white">{service.subtitle}</p>
                </div>
              </div>
            </div>
          ))}
        </section>
      )}

      {/* 🔹 Clients Section */}
      {showClients && (
        <section className="mb-12" data-aos="fade-right">
          <div className="grid lg:grid-cols-6 sm:grid-cols-4 grid-cols-2">
            {clients.map((logo, index) => (
                <div
                  key={index}
                  className="item  w-full h-[130px] bg-white border border-primarygray flex justify-center items-center"
                >
                  <img
                    src={logo}
                    alt={`Client Logo ${index + 1}`}
                    className="max-h-10 object-contain"
                  />
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 🔹 Flash Sale Banner Section */}
      {showFlashSale && (
        <section className="mb-12" data-aos="fade-left">
          <div
            className="bg-pink-200 lg:h-[460px] mb-[60px] overflow-hidden flex flex-col md:flex-row items-center justify-between p-5 md:p-12"
            style={flashSaleStyle}
          >
            <div className="w-full xl:p-12">
              <div className="countdown-wrapper w-full flex space-x-[20px] mb-10">
                <div className="countdown-item">
                  <div className="countdown-number sm:w-[100px] sm:h-[100px] w-[50px] h-[50px] rounded-full bg-white flex justify-center items-center">
                    <span className="font-700 sm:text-[30px] text-[14px] text-[#EB5757]">
                      0
                    </span>
                  </div>
                  <p className="sm:text-[18px] text-[12px] font-500 text-center leading-8">
                    Days
                  </p>
                </div>
                <div className="countdown-item">
                  <div className="countdown-number sm:w-[100px] sm:h-[100px] w-[50px] h-[50px] rounded-full bg-white flex justify-center items-center">
                    <span className="font-700 sm:text-[30px] text-[14px] text-[#2F80ED]">
                      0
                    </span>
                  </div>
                  <p className="sm:text-[18px] text-[12px] font-500 text-center leading-8">
                    Hours
                  </p>
                </div>
                <div className="countdown-item">
                  <div className="countdown-number sm:w-[100px] sm:h-[100px] w-[50px] h-[50px] rounded-full bg-white flex justify-center items-center">
                    <span className="font-700 sm:text-[30px] text-[14px] text-[#219653]">
                      0
                    </span>
                  </div>
                  <p className="sm:text-[18px] text-[12px] font-500 text-center leading-8">
                    Minutes
                  </p>
                </div>
                <div className="countdown-item">
                  <div className="countdown-number sm:w-[100px] sm:h-[100px] w-[50px] h-[50px] rounded-full bg-white flex justify-center items-center">
                    <span className="font-700 sm:text-[30px] text-[14px] text-[#EF5DA8]">
                      0
                    </span>
                  </div>
                  <p className="sm:text-[18px] text-[12px] font-500 text-center leading-8">
                    Seconds
                  </p>
                </div>
              </div>
              <div className="countdown-title mb-4">
                <h1 className="text-[44px] text-qblack font-medium">
                  WOO! Flash Sale
                </h1>
                <p className="text-[18px] text-qblack leading-7">
                  You get into the 2k+ best Products in Flash offer with a{" "}
                  <br />
                  special-shaped sofa for sale.
                </p>
              </div>
              <div className=" w-[100px] h-8 border-b border-qblack">
                <div className=" h-full inline-flex space-x-2  items-center">
                  <span className="text-sm font-600 tracking-wide leading-7">
                    Shop Now →
                  </span>
                  <span></span>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* 🔹 Discount Banner Section */}
      {showDiscountSale && (
        <div
          className="discount-banner w-full h-[307px] bg-cover flex justify-center items-center "
          style={{
            backgroundImage: "url('/Images/discount-banner.jpg')",
            backgroundPosition: "0% 0%",
            backgroundSize: "cover",
            backgroundRepeat: "no-repeat",
          }}
        >
          <div>
            <div data-aos="fade-up">
              <h1 className="sm:text-3xl text-xl font-bold text-qblack mb-2 text-center">
                Get <span className="mx-1 text-pink-400">20%</span> Off Discount
                Coupon
              </h1>
              <p className="text-center sm:text-[18px] text-sm font-400">
                by Subscribe our Newsletter
              </p>
            </div>
            <div
              data-aos="fade-right"
              className="sm:w-[543px] w-[300px] h-[54px] flex mt-8"
            >
              <div className="flex-1 bg-white pl-4 flex space-x-2 items-center h-full focus-within:text-qyellow text-qblack">
                <span>
                  <FaEnvelope />
                </span>
                <input
                  type="email"
                  name="email"
                  className="w-full h-full focus:outline-none text-sm placeholder:text-xs placeholder:text-qblack text-qblack font-400 tracking-wider"
                  placeholder="EMAIL ADDRESS"
                />
              </div>
              <button
                type="button"
                className="inline-block bg-pink-300 hover:bg-pink-400 text-gray-900 sm:w-[158px] w-[80px] font-semibold rounded transition-colors duration-300"
              >
                Get the Coupon
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
