import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import toast from "react-hot-toast";

export default function AuthForm({ title, buttonText, linkText, linkTo }) {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Static credentials
  const validEmail = "admin@example.com";
  const validPassword = "123456";

  const handleSubmit = (e) => {
    e.preventDefault();

    if (title === "Sign In") {
      if (email === validEmail && password === validPassword) {
        toast.success("Login successful!");
        localStorage.setItem("isLoggedIn", "true");
        navigate("/");
      } else {
        toast.error("Invalid email or password");
      }
    } else {
      toast.success("Account created successfully!");
      navigate("/signin");
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 px-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-lg p-8">
        <h2 className="text-2xl font-bold text-center mb-6 text-gray-800">{title}</h2>
        <form className="space-y-5" onSubmit={handleSubmit}>
          <div>
            <label className="block text-gray-700 mb-2 text-sm font-medium">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter your email"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700 mb-2 text-sm font-medium">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter your password"
              required
            />
          </div>

          {title === "Sign Up" && (
            <div>
              <label className="block text-gray-700 mb-2 text-sm font-medium">Confirm Password</label>
              <input
                type="password"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Confirm your password"
                required
              />
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 rounded-lg transition duration-200"
          >
            {buttonText}
          </button>
        </form>

        <p className="text-center text-sm text-gray-600 mt-6">
          {linkText}{" "}
          <Link to={linkTo} className="text-blue-600 hover:underline font-medium">
            Click here
          </Link>
        </p>
      </div>
    </div>
  );
}
