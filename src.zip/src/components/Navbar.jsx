import { Link, useNavigate, useLocation } from "react-router-dom";
import { useState, useEffect, useRef } from "react";
import { useCart } from "../hooks/useCart";
import { products } from "../data/products";
import {
  FaRegHeart,
  FaRegUser,
  FaShoppingCart,
  FaBars,
  FaChevronDown,
  FaBalanceScale,
} from "react-icons/fa";

export default function Navbar() {
  const { cart, wishlist, compare } = useCart();
  const cartCount = cart.reduce((acc, item) => acc + item.qty, 0);
  const wishlistCount = wishlist.length;
  const compareCount = compare.length;

  const [selectedCategory, setSelectedCategory] = useState("All Categories");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCategoryDropdownOpen, setIsCategoryDropdownOpen] = useState(false);

  //dropdown open and close
  const [isOpen, setIsOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const dropdownRef = useRef(null); // search category
  const categoryDropdownRef = useRef(null); // bottom category
  const accountDropdownRef = useRef(null); // user account dropdown
  const navigate = useNavigate();
  const location = useLocation();

  const categories = [
    { name: "All Categories", slug: "all" },
    { name: "Men's", slug: "mens" },
    { name: "Women's", slug: "womens" },
    { name: "Kid's", slug: "kids" },
  ];

  const normalizeCategory = (category) => {
    if (!category) return "";
    return category
      .toLowerCase()
      .replace(/'s/g, "") // remove possessive 's
      .replace(/s$/, ""); // remove trailing s if any
  };

  useEffect(() => {
    // check login status on load
    const loggedIn = localStorage.getItem("isLoggedIn") === "true";
    setIsLoggedIn(loggedIn);
  }, [location.pathname]);

  // ✅ Close dropdowns when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
        setShowSuggestions(false);
      }
      if (
        categoryDropdownRef.current &&
        !categoryDropdownRef.current.contains(event.target)
      ) {
        setIsCategoryDropdownOpen(false);
      }
      if (
        accountDropdownRef.current &&
        !accountDropdownRef.current.contains(event.target)
      ) {
        setIsOpen(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (searchTerm.trim().length > 0) {
      let filtered = products.filter((p) =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase())
      );

      if (selectedCategory && selectedCategory !== "All Categories") {
        filtered = filtered.filter(
          (p) =>
            normalizeCategory(p.category) ===
            normalizeCategory(selectedCategory)
        );
      }

      setSuggestions(filtered);
      setShowSuggestions(true);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [searchTerm, selectedCategory]);

  const handleLogout = (e) => {
    e.preventDefault();
    localStorage.removeItem("isLoggedIn");
    setIsLoggedIn(false);
    setIsOpen(false);
    navigate("/");
  };

  const handleSearch = () => {
    const term = searchTerm.trim().toLowerCase();
    if (!term) return;

    let filtered = products.filter((p) => p.name.toLowerCase().includes(term));

    if (selectedCategory && selectedCategory !== "All Categories") {
      filtered = filtered.filter(
        (p) =>
          normalizeCategory(p.category) === normalizeCategory(selectedCategory)
      );
    }

    // Store results in state or pass via navigation
    navigate("/search", {
      state: {
        results: filtered,
        term,
        category: selectedCategory || "All",
      },
    });
  };

  return (
    <header className="bg-white shadow-md relative z-50">
      {/* Top Header */}
      <div className="bg-white">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          {/* Logo */}
          <a href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-pink-100 rounded-full flex items-center justify-center">
              <div className="w-6 h-6 border-4 border-pink-400 rounded-full"></div>
            </div>
            <h1 className="text-2xl font-bold text-pink-400">E-Shop</h1>
          </a>

          {/* Search Bar (hidden on mobile) */}
          <div className="hidden sm:flex flex-1 max-w-2xl items-center relative" ref={dropdownRef}>
            <input
              type="text"
              placeholder="Search Product..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 px-4 py-2.5 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-pink-300"
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            />
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="px-4 py-2.5 bg-white border-t border-b border-gray-300 flex items-center gap-2 hover:bg-gray-50 whitespace-nowrap"
              >
                {selectedCategory || "Select Category"}
                <FaChevronDown className="w-3 h-3" />
              </button>
              {isDropdownOpen && (
                <div className="absolute top-full right-0 mt-1 w-48 bg-white border border-gray-200 shadow-lg z-50">
                  {categories.map((category) => (
                    <Link
                      key={category.slug}
                      onClick={() => {
                        setSelectedCategory(category.name);
                        setIsDropdownOpen(false);
                      }}
                      className="block w-full text-left px-4 py-2 hover:bg-pink-50 text-sm"
                    >
                      {category.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>
            <button
              onClick={handleSearch}
              className="px-6 py-2.5 bg-pink-400 text-white rounded-r-md hover:bg-pink-500 transition-colors"
            >
              Search
            </button>

            {/* 🧾 Live Suggestions Dropdown */}
            {showSuggestions && (
              <div className="absolute top-full left-0 mt-2 w-full bg-white border border-gray-200 shadow-lg z-50 max-h-80 overflow-y-auto">
                {suggestions.length > 0 ? (
                  suggestions.map((product) => (
                    <Link
                      key={product.id}
                      to={`/product/${product.id}`}
                      className="block px-4 py-2 hover:bg-pink-50 text-sm"
                      onClick={() => setShowSuggestions(false)}
                    >
                      {product.name}
                    </Link>
                  ))
                ) : (
                  <div className="px-4 py-2 text-gray-500 text-sm">
                    No products found
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Icons */}
          <div className="flex items-center gap-4">
            <Link
              to="/compare"
              className="relative hover:text-pink-400 hidden lg:block group"
            >
              <FaBalanceScale className="w-5 h-5" />
              {compareCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-pink-400 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-semibold">
                  {compareCount}
                </span>
              )}
              <span className="absolute top-full left-1/3 -translate-x-1/2 mb-2 text-xs mt-3 bg-white text-black border border-qgray-border py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition">
                Compare
              </span>
            </Link>
            <Link
              to="/wishlist"
              className="relative hover:text-pink-400 hidden lg:block group"
            >
              <FaRegHeart className="w-5 h-5" />
              {wishlistCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-pink-400 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-semibold">
                  {wishlistCount}
                </span>
              )}
              <span className="absolute top-full left-1/3 -translate-x-1/2 mb-2 text-xs mt-3 bg-white text-black border border-qgray-border py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition">
                Wishlist
              </span>
            </Link>
            <Link to="/cart" className="relative hover:text-pink-400 group">
              <FaShoppingCart className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-pink-400 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-semibold">
                  {cartCount}
                </span>
              )}
              <span className="absolute top-full left-1/3 -translate-x-1/2 mb-2 text-xs mt-3 bg-white text-black border border-qgray-border py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition">
                Cart
              </span>
            </Link>
            <div
              ref={accountDropdownRef}
              className="relative hidden lg:block group"
            >
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="hover:text-pink-400 relative"
              >
                <FaRegUser className="w-5 h-5" />
                {/* Tooltip (only when dropdown is closed) */}
                {!isOpen && (
                  <span className="absolute top-full left-1/3 -translate-x-1/2 mb-2 text-xs mt-3 bg-white text-black border border-qgray-border py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition">
                    Account
                  </span>
                )}
              </button>

              {/* Dropdown Menu */}
              {isOpen && (
                <div className="absolute right-0 mt-2 w-36 bg-white border border-gray-200 rounded shadow-lg py-2 z-50">
                  {!isLoggedIn ? (
                    <>
                      <Link
                        to="/signin"
                        className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      >
                        Login
                      </Link>
                    </>
                  ) : (
                    <>
                      <Link
                        to="/myaccount"
                        className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      >
                        My Account
                      </Link>
                      <button
                        type="button"
                        onClick={handleLogout}
                        className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      >
                        Sign Out
                      </button>
                    </>
                  )}
                </div>
              )}
            </div>

            {/* Mobile Hamburger */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="sm:hidden p-2 hover:bg-gray-100 rounded"
            >
              <FaBars className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Navigation (hidden on mobile) */}
      <div className="hidden sm:block bg-pink-200">
        <div className="max-w-7xl mx-auto px-4 py-2 flex items-center justify-between">
          <nav className="flex items-center gap-6">
            {/* Category Dropdown Button */}
            <div className="relative" ref={categoryDropdownRef}>
              <button
                onClick={() =>
                  setIsCategoryDropdownOpen(!isCategoryDropdownOpen)
                }
                className="bg-white px-4 py-3 flex items-center gap-3 hover:bg-gray-50 transition-colors relative"
              >
                <FaBars className="w-5 h-5 text-gray-700" />
                <span className="font-medium text-gray-700">
                  All Categories
                </span>
                <FaChevronDown className="w-3 h-3 text-gray-700" />
              </button>

              {/* Category Dropdown */}
              {isCategoryDropdownOpen && (
                <div className="absolute top-full left-0 mt-1 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-50">
                  {categories.map((category) => (
                    <Link
                      key={category.slug}
                      to={`/category/${category.slug}`}
                      onClick={() => {
                        setSelectedCategory(category.name);
                        setIsCategoryDropdownOpen(false);
                      }}
                      className="block w-full text-left px-4 py-2 hover:bg-pink-50"
                    >
                      {category.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <Link
              to="/productlist"
              className="text-gray-800 hover:text-pink-600 font-medium"
            >
              Shop
            </Link>
            <Link
              to="/about"
              className="text-gray-800 hover:text-pink-600 font-medium"
            >
              About
            </Link>
            <Link
              to="/blog"
              className="text-gray-800 hover:text-pink-600 font-medium"
            >
              Blog
            </Link>
            <Link
              to="/contact"
              className="text-gray-800 hover:text-pink-600 font-medium"
            >
              Contact
            </Link>
          </nav>
          <Link
            to="/becomeseller"
            className="bg-gray-800 text-white px-6 py-2 font-medium hover:bg-gray-900 transition-colors"
          >
            Become a Seller
          </Link>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="sm:hidden absolute top-full left-0 w-full bg-white border-t border-gray-200 shadow-md z-50">
          <div className="flex flex-col gap-1 p-4">
            {/* ✅ Wishlist & Compare Icons Section */}
            <div className="flex items-center gap-6 mb-4">
              <Link
                to="/compare"
                className="relative flex items-center gap-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <FaBalanceScale className="w-5 h-5" />
                <span className="text-sm">Compare</span>
                {compareCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-pink-400 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-semibold">
                    {compareCount}
                  </span>
                )}
              </Link>

              <Link
                to="/wishlist"
                className="relative flex items-center gap-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <FaRegHeart className="w-5 h-5" />
                <span className="text-sm">Wishlist</span>
                {wishlistCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-pink-400 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-semibold">
                    {wishlistCount}
                  </span>
                )}
              </Link>
            </div>
            {/* ✅ Categories */}
            {categories.map((category) => (
              <Link
                key={category.slug}
                to={`/category/${category.slug}`}
                className="w-full text-left px-4 py-2 hover:bg-pink-50 rounded"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {category.name}
              </Link>
            ))}
            <Link
              to="/productlist"
              className="px-4 py-2 hover:bg-pink-50 rounded"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Shop
            </Link>
            <Link
              to="/about"
              className="px-4 py-2 hover:bg-pink-50 rounded"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              About
            </Link>
            <Link
              to="/blog"
              className="px-4 py-2 hover:bg-pink-50 rounded"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Blog
            </Link>
            <Link
              to="/contact"
              className="px-4 py-2 hover:bg-pink-50 rounded"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Contact
            </Link>
            <button
              className="bg-gray-800 text-white px-6 py-2 mt-2 rounded hover:bg-gray-900"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Become a Seller
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
