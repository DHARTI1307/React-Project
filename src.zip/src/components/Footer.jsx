//import { useState } from "react";

export default function Footer() {
  return (
    <footer className="footer-section-wrapper" data-aos="fade-up" style={{ backgroundImage: "url('/Images/footer.png')" }}>
      <div className="max-w-6xl mx-auto px-4 py-12 block pt-[83px]">
        <div className="lg:flex justify-between mb-[50px]">
          <div className="lg:w-4/10 w-full mb-10 lg:mb-0">
            <div className="mb-14">
             <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-pink-100 rounded-full flex items-center justify-center">
                <div className="w-6 h-6 border-4 border-pink-400 rounded-full"></div>
              </div>
              <h1 className="text-2xl font-bold">
                <span className="text-pink-400">E-Shop</span>
              </h1>
            </div>
            </div>
            <div>
                <p className="text-white font-sm">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                </p>
              {/* <ul className="flex flex-col space-y-5 ">
                <li>
                  <a href="/">
                    <span className="text-white text-[15px] hover:text-[#9a9a9a] hover:underline">
                      Track Order
                    </span>
                  </a>
                </li>
                <li>
                  <a href="/">
                    <span className="text-white text-[15px] hover:text-[#9a9a9a] hover:underline">
                      Delivery &amp; Returns
                    </span>
                  </a>
                </li>
                <li>
                  <a href="/">
                    <span className="text-white text-[15px] hover:text-[#9a9a9a] hover:underline">
                      Warranty
                    </span>
                  </a>
                </li>
              </ul> */}
            </div>
          </div>
          <div className="lg:w-2/10 w-full mb-10 lg:mb-0 lg:ml-8">
            <div className="mb-5">
              <h6 className="font-500 text-[20px] text-pink-400">Company</h6>
            </div>
            <div>
              <ul className="flex flex-col space-y-5 ">
                <li>
                  <a href="/about">
                    <span className="text-white text-[15px] hover:text-pink-400">
                      About Us
                    </span>
                  </a>
                </li>
                <li>
                  <a href="/contact">
                    <span className="text-white text-[15px] hover:text-pink-400">
                     Contact Us
                    </span>
                  </a>
                </li>
                <li>
                  <a href="blog">
                    <span className="text-white text-[15px] hover:text-pink-400">
                     Blog
                    </span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="lg:w-2/10 w-full mb-10 lg:mb-0 ">
            <div className="mb-5">
              <h6 className="font-500 text-[20px] text-pink-400">Quick Links</h6>
            </div>
            <div>
              <ul className="flex flex-col space-y-5 ">
                <li>
                  <a href="/productlist">
                    <span className="text-white text-[15px] hover:text-pink-400">
                      Shop
                    </span>
                  </a>
                </li>
                <li>
                  <a href="/wishlist">
                    <span className="text-white text-[15px] hover:text-pink-400">
                     Wishlist
                    </span>
                  </a>
                </li>
                <li>
                  <a href="/cart">
                    <span className="text-white text-[15px] hover:text-pink-400">
                      Shopping Cart
                    </span>
                  </a>
                </li>
               
              </ul>
            </div>
          </div>
          <div className="lg:w-2/10 w-full mb-10 lg:mb-0">
            <div className="mb-5">
              <h6 className="font-500 text-[20px] text-pink-400">Useful Links</h6>
            </div>
            <div>
              <ul className="flex flex-col space-y-5 ">
                <li>
                  <a href="/becomeseller" className="group">
                    <span className=" text-white text-[15px] hover:text-pink-400">
                      Become a seller
                    </span>
                  </a>
                </li>
                <li>
                  <a href="/privacypolicy">
                    <span className="text-white text-[15px] hover:text-pink-400">
                      Privacy Policy
                    </span>
                  </a>
                </li>
                <li>
                  <a href="/termsandcondition">
                    <span className="text-white text-[15px] hover:text-pink-400">
                      Terms of Use
                    </span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="bottom-bar border-t border-qgray-border lg:h-[82px] lg:flex justify-between items-center">
          <div className="flex lg:space-x-5 py-2 justify-between items-center mb-3">
            <span className="sm:text-base text-[14px] text-white font-300">
              ©2025
              <a
                href=""
                target="_blank"
                rel="noreferrer"
                className="font-500 text-qh4-pink mx-1"
              >
               Copyright &
              </a>
              All rights reserved
            </span>
          </div>
          <div className="">
            <a href="#">
                <img src="/Images/payment-getways.png"/>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
