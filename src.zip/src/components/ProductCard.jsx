// src/components/ProductCard.jsx
import { useState } from "react";
import { Link } from "react-router-dom";
import toast from "react-hot-toast";
import { useCart } from "../hooks/useCart";
import {
  FaShoppingCart,
  FaRegHeart,
  FaBalanceScale,
  FaStar,
} from "react-icons/fa";

export default function ProductCard({ product }) {
  const { addToCart, addToWishlist, addToCompare } = useCart();
  const [qty] = useState(1);
  // const navigate = useNavigate();

  // const increaseQty = () => setQty((prev) => prev + 1);
  // const decreaseQty = () => setQty((prev) => (prev > 1 ? prev - 1 : 1));

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart({ ...product, qty });
    toast.success("🛒 Item added to cart successfully!", {
      position: "top-right",
    });
  };

  const handleWishlist = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToWishlist(product);
    toast.success("Item added to wishlist successfully!", {
      position: "top-right",
    });
  };

  const handleCompare = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCompare(product);
    toast.success("Item added to compare successfully!", {
      position: "top-right",
    });
  };

  return (
    <div className="item" data-aos="fade-up">
      <div className="group w-full h-[460px] bg-white shadow hover:shadow-lg relative p-3.5 mb-6 transition flex flex-col content-center overflow-hidden">
        <Link to={`/product/${product.id}`}>
          <img
            src={product.image}
            alt={product.name}
            className="cursor-pointer product-card-img w-full h-[330px] object-cover"
          />
        </Link>
        <div className="product-card-details px-[20px] pt-[20px] pb-[10px] relative">
          <Link to={`/product/${product.id}`}>
            <h2 className="text-xl leading-6 font-medium text-qblack mb-2 hover:text-pink-500 transition">
              {product.name}
            </h2>
          </Link>
          <div className="flex items-center gap-1 text-yellow-400 mb-2">
            {[...Array(5)].map((_, i) => (
              <FaStar key={i} />
            ))}
          </div>
          <p className="price">
            <span className="main-price text-gray-600 line-through font-600 text-[18px]">
              ₹{product.oldprice}
            </span>
            <span className="offer-price text-red-600 font-600 text-[18px] ml-2">
              ₹{product.price}
            </span>
          </p>
        </div>
        <div
          className="quick-access-btns flex flex-col space-y-2 absolute right-4 top-20 
      opacity-0 translate-x-5 
      group-hover:opacity-100 group-hover:translate-x-0 
      transition-all duration-300 ease-in-out"
        >
          <button className="relative group/item" onClick={handleCompare}>
            <span className="w-10 h-10 flex justify-center items-center bg-primarygray rounded transition-colors duration-200 delay-75 group-hover/item:bg-pink-500">
              <FaBalanceScale className="w-5 h-5" />
            </span>
             {/* Tooltip */}
            <span class="absolute top-1/2 right-12 -translate-y-1/2 text-xs bg-white text-black border border-gray-300 rounded px-2 py-1 opacity-0 group-hover/item:opacity-100 transition">
              Compare
            </span>
          </button>
          <button className="relative group/item" onClick={handleWishlist}>
            <span className="w-10 h-10 flex justify-center items-center bg-primarygray rounded group-hover/item:bg-pink-500 transition">
              <FaRegHeart className="w-5 h-5" />
            </span>
              {/* Tooltip */}
            <span class="absolute top-1/2 right-12 -translate-y-1/2 text-xs bg-white text-black border border-gray-300 rounded px-2 py-1 opacity-0 group-hover/item:opacity-100 transition">
              Wishlist
            </span>
          </button>
        </div>
        <div className="w-full h-8 px-[30px] absolute lg:-bottom-10 lg:group-hover:bottom-3 bottom-3 left-0 transition-all duration-300 ease-in-out">
          <button
            onClick={handleAddToCart}
            className="black-btn w-full h-full flex justify-center items-center"
          >
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}

{
  /* Quantity Selector */
}
{
  /* <div className="flex items-center gap-2 mb-3">
        <button onClick={decreaseQty} className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1 rounded">
          -
        </button>
        <span>{qty}</span>
        <button onClick={increaseQty} className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1 rounded">
          +
        </button>
      </div> */
}
{
  /* <div className="flex gap-2">
          <button onClick={handleAddToCart} className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg">
              Add to Cart
          </button>
          <button onClick={() => addToWishlist(product)} className="bg-pink-500 hover:bg-pink-600 text-white px-4 py-1 rounded">
              Add to Wishlist
          </button>
       </div> */
}

{
  /* <div className="item group">
      <Link
        to={`/product/${product.id}`}
        className="w-full h-[380spx] bg-white shadow hover:shadow-lg relative p-3.5 mb-6 transition flex flex-col content-center overflow-hidden"
      >
        <img
          src={product.image}
          alt={product.name}
          className="cursor-pointer"
        />

        <div className="quick-access-btns flex flex-col space-y-2 absolute group-hover:right-4 -right-10 top-20  transition-all duration-300 ease-in-out">
          <button onClick={handleCompare}>
            <span className="w-10 h-10 flex justify-center items-center bg-primarygray rounded">
              <FaBalanceScale className="w-5 h-5" />
            </span>
          </button>
           <button onClick={handleWishlist}>
            <span className="w-10 h-10 flex justify-center items-center bg-primarygray rounded">
              <FaRegHeart className="w-5 h-5" />
            </span>
          </button>
        </div>
        <div className="absolute w-full h-10 px-[30px]  left-0 -bottom-10 group-hover:bottom-5 transition-all duration-300 ease-in-out">
          <button
            onClick={handleAddToCart}
            className="black-btn w-full h-full flex justify-center items-center"
          >
            Add to Cart
          </button>
        </div>
      </Link>
      <Link to={`/product/${product.id}`}>
        <h2 className="text-xl leading-6 font-medium text-qblack mb-2 hover:text-pink-500 transition">
          {product.name}
        </h2>
      </Link>
      <p className="text-gray-600 text-base leading-6 font-medium text-qgraytwo">
        ₹{product.price}
      </p>
    </div> */
}
