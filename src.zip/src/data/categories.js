export const categories = [
  {
    id: 1,
    name: "Men's",
    slug: "mens",
    image: "/Images/men.jpg" ,
    // subcategories: [
    //   { name: "Liqueur", slug: "liqueur", image: "/images/liqueur.jpg" },
    // ],
  },
  {
    id: 2,
    name: "Women's",
    slug: "womens",
    image: "/Images/women.jpg", 
    // subcategories: [
    //   { name: "Red Wine", slug: "red-wine", image: "/images/redwine.jpg" },
    // ],
  },
  {
    id: 3,
    name: "Kid's",
    slug: "kids",
    image: "/Images/kid.jpg", 
    // subcategories: [
    //   { name: "Red Wine", slug: "red-wine", image: "/images/redwine.jpg" },
    // ],
  },
];