import { useEffect } from "react";
import { initializeAOS } from "./utils/aosSetup";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Home from "./pages/Home";
import ProductList from "./pages/ProductList";
import ProductDetail from "./pages/ProductDetail";
import Cart from "./pages/Cart";
import Checkout from "./pages/Checkout";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import ScrollToTop from "./components/ScrollToTop";
import WishlistPage from "./pages/Wishlist";
import ComparePage from "./pages/Compare";
import CategoryPage from "./pages/Category";
import AboutPage from "./pages/About";
import BlogPage from "./pages/Blog";
import ContactPage from "./pages/Contact";
import BecomeSellerPage from "./pages/BecomeSeller";
import TermsandConditionPage from "./pages/TermsandCondition";
import PrivacyPolicyPage from "./pages/PrivacyPolicy";
import SignInPage from "./pages/SignIn";
import SignUpPage from "./pages/SignUp";
import MyaccountPage from "./pages/Myaccount";
import SearchPage from "./pages/Search";

export default function App() {
   useEffect(() => {
    initializeAOS();
  }, []);
  return (
    <BrowserRouter>
      <Toaster position="top-right" reverseOrder={false} />
      <Navbar />
      <ScrollToTop /> 
      <Routes>
        {/* <Route path="/" element={<SignInPage />} /> */}
        <Route path="/signin" element={<SignInPage />} />
        <Route path="/signup" element={<SignUpPage />} />
        <Route path="/" element={<Home />} />
        <Route path="/productlist" element={<ProductList />} />
        <Route path="/product/:id" element={<ProductDetail />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/checkout" element={<Checkout />} />
        <Route path="/wishlist" element={<WishlistPage />} />
        <Route path="/compare" element={<ComparePage />} />
        <Route path="/category/:categorySlug" element={<CategoryPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/becomeseller" element={<BecomeSellerPage />} />
        <Route path="/termsandcondition" element={<TermsandConditionPage />} />
        <Route path="/privacypolicy" element={<PrivacyPolicyPage />} />
        <Route path="/myaccount" element={<MyaccountPage />} />
        <Route path="/search" element={<SearchPage />} />
      </Routes>
      <Toaster />
       <Footer data-aos="fade-up"/>
    </BrowserRouter>
  );
}

// function Layout() {
//   const location = useLocation();
//   const hideLayoutRoutes = ["/signin", "/signup"]; // routes to hide header/footer
//   const hideLayout = hideLayoutRoutes.includes(location.pathname);

//   return (
//      <>
//       {!hideLayout && <Navbar />}
//        <Toaster position="top-center" reverseOrder={false} />
//       <Routes>
//         {/* <Route path="/" element={<SignInPage />} /> */}
//         <Route path="/signin" element={<SignInPage />} />
//         <Route path="/signup" element={<SignUpPage />} />
//         <Route path="/" element={<Home />} />
//         <Route path="/productlist" element={<ProductList />} />
//         <Route path="/product/:id" element={<ProductDetail />} />
//         <Route path="/cart" element={<Cart />} />
//         <Route path="/checkout" element={<Checkout />} />
//         <Route path="/wishlist" element={<WishlistPage />} />
//         <Route path="/compare" element={<ComparePage />} />
//         <Route path="/category/:categorySlug" element={<CategoryPage />} />
//         <Route path="/about" element={<AboutPage />} />
//         <Route path="/blog" element={<BlogPage />} />
//         <Route path="/contact" element={<ContactPage />} />
//         <Route path="/becomeseller" element={<BecomeSellerPage />} />
//         <Route path="/termsandcondition" element={<TermsandConditionPage />} />
//         <Route path="/privacypolicy" element={<PrivacyPolicyPage />} />
//         <Route path="/myaccount" element={<MyaccountPage />} />
//       </Routes>
//       {!hideLayout && <Footer />}
//       <Toaster />
//       </>
//   );
// }

// export default function App() {
//   return (
//     <BrowserRouter>
//       <Layout />
//     </BrowserRouter>
//   );
// }
